import pack.DayofYearSet;
import java.util.*;

/**
 * Driver class runs all the methods twice
 */
public class Driver{  
    public static void main(String[] args){
        //*************************** DE MORGAN TEST *************************
        // Also constructors, add, equals methods are testing in here
        // Inside those methods, getDay, getMonth, size, checkMonthValidity, checkDayValidity methods are also tested.
        // User input is controled in the constructors' check methods.
        System.out.println("\n\nDe Morgan says that !(s1 + s2) == !s1 ^ !s2\n\n");

        // DE MORGAN TEST 0
        ArrayList<DayofYearSet.DayofYear> testSet1 = new ArrayList<>();
        ArrayList<DayofYearSet.DayofYear> testSet2 = new ArrayList<>();

        // DE MORGAN TEST 1
        DayofYearSet s1 = new DayofYearSet();
        DayofYearSet s2 = new DayofYearSet();

        s1.add(new DayofYearSet.DayofYear(6,1));
        s1.add(new DayofYearSet.DayofYear(21,4));
        s1.add(new DayofYearSet.DayofYear(30,8));
        s1.add(new DayofYearSet.DayofYear(9,6));

        s2.add(new DayofYearSet.DayofYear(4,2));
        s2.add(new DayofYearSet.DayofYear(3,4));
        s2.add(new DayofYearSet.DayofYear(11,7));
        s2.add(new DayofYearSet.DayofYear(13,12));
        s2.add(new DayofYearSet.DayofYear(19,9));

        System.out.println("De Morgan 1 is testing...\n");
        System.out.println("In condition first set has less element than second...\n");
        s1.testDeMorgan(s2);

        // DE MORGAN TEST 2
        System.out.println("\n");
        DayofYearSet s3 = new DayofYearSet();
        DayofYearSet s4 = new DayofYearSet();

        s3.add(new DayofYearSet.DayofYear());
        s3.add(new DayofYearSet.DayofYear(1,5));
        s3.add(new DayofYearSet.DayofYear(2,3));
        s3.add(new DayofYearSet.DayofYear(10,7));
        s3.add(new DayofYearSet.DayofYear(5,10));

        s4.add(new DayofYearSet.DayofYear(7,11));
        s4.add(new DayofYearSet.DayofYear(4,4));
        s4.add(new DayofYearSet.DayofYear(1,7));
        s4.add(new DayofYearSet.DayofYear(3,12));
 
        System.out.println("De Morgan 2 is testing...\n");
        System.out.println("In condition second set has less element than first...\n");
        s3.testDeMorgan(s4);

        // DE MORGAN TEST 3
        System.out.println("\n");
        DayofYearSet s5 = new DayofYearSet();
        DayofYearSet s6 = new DayofYearSet();

        s5.add(new DayofYearSet.DayofYear(8,2));
        s5.add(new DayofYearSet.DayofYear(8,6));
        s5.add(new DayofYearSet.DayofYear(7,5));
        s5.add(new DayofYearSet.DayofYear(6,9));

        s6.add(new DayofYearSet.DayofYear(4,11));
        s6.add(new DayofYearSet.DayofYear(3,10));
        s6.add(new DayofYearSet.DayofYear(1,9));
        s6.add(new DayofYearSet.DayofYear(2,2));

        System.out.println("De Morgan 3 is testing...\n");
        System.out.println("In condition second set has equal element with first...\n");
        s5.testDeMorgan(s6);

        // DE MORGAN TEST 4
        System.out.println("\n");
        DayofYearSet s7 = new DayofYearSet();
        DayofYearSet s8 = new DayofYearSet();

        s7.add(new DayofYearSet.DayofYear(21,11));
        s7.add(new DayofYearSet.DayofYear(30,12));
        s7.add(new DayofYearSet.DayofYear(3,4));

        s8.add(new DayofYearSet.DayofYear(27,11));
        s8.add(new DayofYearSet.DayofYear(28,2));
        s8.add(new DayofYearSet.DayofYear(11,6));

        System.out.println("De Morgan 4 is testing...\n");
        s7.testDeMorgan(s8);

        // DE MORGAN TEST 5
        System.out.println("\n");
        DayofYearSet s9 = new DayofYearSet();
        DayofYearSet s10 = new DayofYearSet();

        s9.add(new DayofYearSet.DayofYear(24,5));
        s9.add(new DayofYearSet.DayofYear(16,5));

        s10.add(new DayofYearSet.DayofYear(4,1));
        s10.add(new DayofYearSet.DayofYear(3,2));

        System.out.println("De Morgan 5 is testing...\n");
        s9.testDeMorgan(s10);
       
        //************************** UNION TEST ************************
        System.out.println("\n");
        // toString, isExist methods and constructors are also tested inside here.
        DayofYearSet testUnion = new DayofYearSet();
        System.out.println("Union is testing...\n");
        System.out.println("Set1: \n");
        s1.toString();
        System.out.println("Set2: \n");
        s2.toString();
        System.out.println("Union set of set1 and set2 is: \n");
        testUnion = s1.union(s2);
        testUnion.toString();

        //************************** INTERSECTION TEST *************************
        System.out.println("\n");
        DayofYearSet testIntersection = new DayofYearSet();
        System.out.println("Intersection is testing...\n");
        System.out.println("Set3: \n");
        s3.toString();
        System.out.println("Set4: \n");
        s4.toString();
        System.out.println("Union set of set3 and set4 is: \n");
        testIntersection = s3.intersection(s4);
        testIntersection.toString();

        //************************** DIFFERENCE TEST *************************
        System.out.println("\n");
        DayofYearSet testDiff = new DayofYearSet();
        System.out.println("Difference is testing...\n");
        System.out.println("Set5: \n");
        s5.toString();
        System.out.println("Set6: \n");
        s6.toString();
        System.out.println("Difference set of set5 and set6 is: \n");
        testDiff = s5.difference(s6);
        testDiff.toString();

        //*************************** COMPLEMENT TEST *************************
        // Printing this part on terminal costs lots of line and confusion so that I wrote the complement set to the file named complementSet.txt
        System.out.println("\n");        
        // defineWholeDays, twentyEight, thirty, thirtyOne methods are also tested in here.
        DayofYearSet testComp = new DayofYearSet();
        System.out.println("Complement is testing...\n");
        System.out.println("Set7: \n");
        s7.toString();
        System.out.println("Result of complement is... IT IS TOO LONG\n");
        testComp = s7.complement();
        testComp.toString();
        System.out.println("COMPLEMENT IS END.\n");        
        //*************************** REMOVE TEST *************************
        System.out.println("\n");        
        System.out.println("Removing is testing...\n");
        System.out.println("set8 before removing: \n");
        s8.toString();
        s8.remove(27, 11);
        System.out.println("\nset8 after removing (27, 11): \n");
        s8.toString();
        DayofYearSet.DayofYear obj = new DayofYearSet.DayofYear(11, 6);
        System.out.println("set8 after removing obj, which is (11, 6): \n");
        s8.remove(obj);
        s8.toString();

        //*************************** STATIC TOTAL METHOD TESTS *************************
        System.out.println("\n");    
        System.out.println("getTotalDayofYearObj is testing...\n");
        System.out.println("getTotalDayofYearObj " + DayofYearSet.getTotalDayofYearObj());
    }  
}

/*
    WHOLE METHODS (THEY ALL BEEN TESTED)
DayofYear()
DayofYear(int d, int m)
int getDay()
int getMonth()
boolean checkMonthValidity(int m)
boolean checkDayValidity(int d, int m)
DayofYearSet()
DayofYearSet(int d, int m)
DayofYearSet(ArrayList <DayofYear> objs)
static int getTotalDayofYearObj()
int size()
String toString()
boolean equals(DayofYearSet obj)
void add(DayofYear obj)
void add(int d, int m)
void remove(DayofYear obj)
void remove(int d, int m) 
DayofYearSet union(DayofYearSet obj2)
DayofYearSet clone() 
boolean isExist(DayofYearSet obj2)
DayofYearSet intersection(DayofYearSet obj2)
DayofYearSet difference(DayofYearSet obj2)
DayofYearSet complement()
static void countDayofYearObjs(char flag)
DayofYearSet defineWholeDays()
void twentyEight(DayofYearSet temp)
void thirty(DayofYearSet temp, int m)
void thirtyOne(DayofYearSet temp, int m)
void testDeMorgan(DayofYearSet s1, DayofYearSet s2)
*/
