// DayofYearSet.java program
package pack;
import java.util.*;

/**
 * DayOfYearSet is a class constructed from DayOfYear objects 
 * @author Asuman Sare ERGUT
 */

/**
 * General informations about set:
 * Has a static inner class named DayOfYear
 * Has private data members: a DayofYear array, an integer that counts number of elements in array, and a static integer that holds all living objects 
 * Has constructors, necessary getters and setters,  overridden methods(toString, equals), and other necessary helper methods
 */
public class DayofYearSet{  
    private DayofYear[] DayofYearArray = new DayofYear[365]; 
    private int amountOfElements = 0;   
    private static int totalDayofYearObj;
    // Static inner class means  you can access it without creating an object of the outer class.
    /**
     * General informations about inner class:
     * Has private data members: day and month
     * Has constructors, necessary getters and setters, and other necessary helper methods
     */
    public static class DayofYear{
        // Private data members
        private int day;
        private int month;
    /* Constructors */
        /**
         * Constructs 1 January as default 
         */
        public DayofYear(){
            day = 1;
            month = 1;
        }

        /**
         * Constructer that sets the object as intented 
         */
        public DayofYear(int d, int m){
            if(checkMonthValidity(m) && checkDayValidity(d, m))
            {
                day = d;
                month = m;
            }
            else
            {
                System.out.println("No Such Date\n ");
            }
        }

    /* Necessary setters and getters */
        /**
         * {@code getDay()} returns private data member day
         */
        public int getDay() {return day;}

        /**
         * {@code getMonth()} returns private data member month
         */
        public int getMonth() {return month;}
        public void setDay(int d) {day = d;}
        public void setMonth(int m) {month = m;}

    /* Other necessary helper methods */
        /**
         * {@code checkMonthValidity} takes 
         * @param m which is a month value and returns true if it valid
         */
        public boolean checkMonthValidity(int m){
            // Month values should be between 1 and 12
            boolean retValue = true;
            if ((m < 1) || (m > 12))
            {
                System.out.println("No such month!");
                retValue = false;
            }
            return retValue;
        }

        /**
         * {@code checkDayValidity} takes 
         * @param d and 
         * @param m which are day and month value and returns true if it valid
         */
        public boolean checkDayValidity(int d, int m){
            // Day values is month-depended. Each month has it's own restriction        
            boolean retValue = true;
            if(m == 2) // Month number 2 is belong to February
            {
                if ((d < 1) || (d > 28))
                    retValue = false;
            }
            else if(m <= 7 && (m == 8 || m % 2 == 1)) 
            {
                if ((d < 1) || (d > 31))
                    retValue = false;
            }
            else if(m >= 8 && (m == 8 || m % 2 == 0)) 
            {
                if ((d < 1) || (d > 31))
                    retValue = false;
            }
            else
            {
                if ((d < 1) || (d > 30))
                    retValue = false;
            }
            return retValue;
        }
    } // end class DayofYear            

/* Constructors */
    
    public DayofYearSet() {/* empty */}

    /**
        * From entered 
        * @param d which is day and 
        * @param m which is month values, a new referance will be created in type DayofYear
    */
    public DayofYearSet(int d, int m){
        add(new DayofYear(d, m));
    }

    /**
        * Constructor that takes 
        * @param a ArrayList of DayofYear objects
    */
    public DayofYearSet(ArrayList <DayofYear> objs){
        for(int i = 0; i < objs.size(); ++i)  // Contrary to Java objects, arraylist shows it's size with size() 
            add(objs.get(i)); 
    }

    /**
        * Constructor that takes 
        * @param objs which is DayofYear objects
    */
    public DayofYearSet(DayofYear objs){
        for(int i = 0; i < this.size(); ++i)  // Contrary to Java objects, arraylist shows it's size with size() 
            add(objs); 
    }
    
/* Necessary getters and setters */

    // Method that returns the total number of DayofYear objects alive in all the sets.
    /**
         * {@code getTotalDayofYearObj()} returns private data member totalDayofYearObj
    */
    public static int getTotalDayofYearObj() {return totalDayofYearObj;}

    /**
         * {@code size()} returns private data member size
    */
    public int size(){return amountOfElements;}

/* Overridden methods */

    /* 
       There is no need to return a string so that I used print method instead of format one, 
       in Java everything is converting to string, so that returning anything is okey.
       DayofYearSet holds the array, so that overriden toString method should print this array's components 
       which are mountOfElements, totalDayofYearObj and of course DayofYearArray
    */

    @Override
    public String toString(){
    for(int i=0; i<this.amountOfElements; ++i)
        System.out.printf("%dth element:  Day is: %d . %d\n", i+1, DayofYearArray[i].getDay(), DayofYearArray[i].getMonth());
    System.out.printf("amountOfElements: %d\n", this.amountOfElements);
    System.out.println("getTotalDayofYearObj " + DayofYearSet.getTotalDayofYearObj());
    return "done";
    } 

    /**
     * @Override
     */
    public boolean equals(DayofYearSet obj){
        int count = 0;
        if(this.size() != obj.size())
            return false;
        for(int i=0; i<obj.size(); ++i)
        {
            if((this.DayofYearArray[i].getDay() == obj.DayofYearArray[i].day) && (this.DayofYearArray[i].month == obj.DayofYearArray[i].getMonth()))
                ++count;
        }
        if(count == obj.size())
            return true;
        else  
            return false;
    }

    /**
     * @Override
     */
    public boolean equals(DayofYear obj1, DayofYear obj2){
        boolean if_result;
        if_result = ((obj1.getDay() == obj2.getDay()) && (obj1.getMonth() == obj2.getMonth()));
        if(if_result == false)
            return false;
        else
            return true;
    }

/* Other necessary helper methods */

    /**
        * add method has two type: one of them is that takes 
        * @param obj which is DayofYear object
        * and calls {@code setAndIncArrSize()} method inside it.
        * the other one is that takes 
        * @param d which is day and 
        * @param m which is month values
    */
    public void add(DayofYear obj){
        setAndIncArrSize(obj);
    }

    public void add(int d, int m){
        add(new DayofYearSet.DayofYear(d, m));
    }

    /**
        * {@code remove()} method removes the incoming
        * @param obj from the caller set
    */
    public void remove(DayofYear obj){
        for(int i=0; i<this.size(); ++i)
        {
            if(equals(this.DayofYearArray[i], obj))
            {
                for(int j=i; j<this.size()-1; ++j)
                    this.DayofYearArray[j] = this.DayofYearArray[j+1];
                --(this.amountOfElements);
                this.countDayofYearObjs('-');
            }
        }
    }   

    public void remove(int d, int m) {
        remove(new DayofYear(d, m));
    }   

    /**
        * {@code setAndIncArrSize()} takes
        * @param obj and assigns it to the DayofYearArray
    */
    public void setAndIncArrSize(DayofYear obj){
        DayofYearArray[amountOfElements] = obj;
        ++amountOfElements;
        countDayofYearObjs('+');
    }

    /**
        * {@code clone()} method makes a copy of the object on which it is called.
    */
    public DayofYearSet clone() {
        // Here this keyword represents set of DayOfYear object
        DayofYearSet temp = new DayofYearSet();
        int d, m;
        for(int i=0; i<amountOfElements; ++i)
        {
            d = this.DayofYearArray[i].getDay();
            m = this.DayofYearArray[i].getMonth();
            temp.add(d, m);
        }   
        temp.amountOfElements = this.amountOfElements;
        return temp;
    }

    /**
        * {@code isExist()} method controls whether
        * @param obj is there in the caller set
    */
    public boolean isExist(DayofYear obj){
        // Caller of the method is in type DayofYearSet 
        for(int i= 0; i<this.size(); ++i)
        {
            if((obj.getDay() == this.DayofYearArray[i].getDay()) && obj.getMonth() == this.DayofYearArray[i].getMonth())
                return true;
        }        
        return false;
    }
    
    /**
        * {@code union()} method gets together
        * @param obj2 with caller set this. 
    */
    public DayofYearSet union(DayofYearSet obj2) {
        /*
             To attach two DayofYearSet, we have to create an empty one at first.
             Assignment operator doesn't simply works as we want because there is no actual objects in Java.
             Apart from that, we need to use overridden clone method
        */
        DayofYearSet unionSet = new DayofYearSet();

        for (int i = 0; i < this.size(); ++i) 
        {
            unionSet.add(this.DayofYearArray[i]);
        }

        for(int i= 0; i<obj2.size(); ++i)
        {
            if (unionSet.isExist(obj2.DayofYearArray[i]) == false) 
                unionSet.add(obj2.DayofYearArray[i]);
        }
        return unionSet;
    }


    /**
        * {@code intersection()} method finds the common elements in the
        * @param obj2 and it's caller set
    */
    public DayofYearSet intersection(DayofYearSet obj2){
        DayofYearSet intersectionSet = new DayofYearSet();

        if(this.size() <= obj2.size())
        {
            for(int i= 0; i<obj2.size(); ++i)
            {
                if (this.isExist(obj2.DayofYearArray[i]) == true) 
                    intersectionSet.add(obj2.DayofYearArray[i]);
            }
        }
        else
        {
            for(int i= 0; i<this.size(); ++i)
            {
                if (obj2.isExist(this.DayofYearArray[i]) == true) 
                    intersectionSet.add(this.DayofYearArray[i]);
            }
        }
        return intersectionSet;
    }
    

    /**
        * {@code difference()} method finds the difference in the
        * @param obj2 and it's caller set
    */
    public DayofYearSet difference(DayofYearSet obj2){
        // First check whether there is any common element, than remove it from the caller referance
        for(var i= 0; i<obj2.size(); ++i)
        {
            for(int j=0; j<this.size(); ++j)
            {
                if(this.isExist(obj2.DayofYearArray[i]) == true)
                {
                    remove(new DayofYear(this.DayofYearArray[j].getDay(), this.DayofYearArray[j].getMonth()));
                } 
            }
        }
        return this;
    }


    /**
        * {@code complement()} method finds rest of the days except caller set's elements
    */
    public DayofYearSet complement(){
        DayofYearSet temp = new DayofYearSet();
        temp = this.defineWholeDays();

        for(int i=0; i<this.size(); ++i)
        {
            temp.remove(this.DayofYearArray[i]);
        }
        return temp;
    }
    
    /**
        * {@code countDayofYearObjs()} method that counts the total number of DayofYear objects alive in all the sets.
        * @param flag indcate wheter increment or decrement
    */
    public static void countDayofYearObjs(char flag){
        if(flag == '+')
            ++totalDayofYearObj;
        else if(flag == '-')
            --totalDayofYearObj;
        else 
            System.out.println("Invalid operation selection!");
    }
    
    /**
        * {@code defineWholeDays()} sets the 365 day
    */
    public DayofYearSet defineWholeDays(){
        DayofYearSet temp = new DayofYearSet();
        thirtyOne(temp, 1);
        twentyEight(temp);
        thirtyOne(temp, 3);
        thirty(temp, 4);
        thirtyOne(temp, 5);
        thirty(temp, 6);
        thirtyOne(temp, 7);
        thirtyOne(temp, 8);
        thirty(temp, 9);
        thirtyOne(temp, 10);
        thirty(temp, 11);
        thirtyOne(temp, 12);
        return temp;
    }

    /**
        * {@code twentyEight()} sets the february
    */
    public void twentyEight(DayofYearSet temp){
        for(int i=1; i<=28; ++i)
        {
            temp.add(i, 2);
        }
    }

    /**
        * {@code thirty()} sets months that has 30 days
    */
    public void thirty(DayofYearSet temp, int m){
        for(int i=1; i<=30; ++i)
        {
            temp.add(i, m);
        }
    }

    /**
        * {@code thirtyOne()} sets months that has 31 days
    */
    public void thirtyOne(DayofYearSet temp, int m){
        for(int i=1; i<=31; ++i)
        {
            temp.add(i, m);
        }
    }    

    /**
        * {@code testDeMorgan()} controls the De Morgan rule in set
        * @param s2 and it's caller.
    */
    public void testDeMorgan(DayofYearSet s2){
        // De Morgan says that !(s1 + s2) == !s1 ^ !s2
        // First create a copy of the incoming sets
        DayofYearSet Set1 = new DayofYearSet();
        DayofYearSet Set2 = new DayofYearSet();
        Set1 = this.clone();
        Set2 = s2.clone();
        DayofYearSet test1 = new DayofYearSet();
        DayofYearSet test2 = new DayofYearSet();
        test1 = (Set1.union(Set2)).complement();            // !(s1 + s2)
        // After the left side of the De Morgan rule is tested, not to affect the result, for right side of the rule, variables are refreshed as begin
        Set1 = this.clone();
        Set2 = s2.clone();
        Set1 = Set1.complement();                           // !s1     
        Set2 = Set2.complement();                           // !s2
        test2 =  Set1.intersection(Set2);                   // !s1 ^ !s2
        if(test1.equals(test2))                             // !(s1 + s2) == !s1 ^ !s2
            System.out.println("De Morgan rule is provided by set pairs\n");
        else
            System.out.println("De Morgan rule is not provided by set pairs\n");
        
    }
} // end class DayofYearSet
