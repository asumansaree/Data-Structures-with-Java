
**********

*Intended Javadoc's are available in the folders. 

*Makefile run's command ">> output", everything in the terminal are written to there.

*Examlpe sets are in sets.txt file
**********
