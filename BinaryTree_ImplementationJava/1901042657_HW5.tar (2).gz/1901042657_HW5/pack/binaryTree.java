package pack;
import java.io.*;
import java.util.Scanner;


/** Class for a binary tree that stores type E objects. */
public class binaryTree<E> implements Serializable 
{
    // Inner class Node<E> 
    /** Class to encapsulate a tree node. */
    protected static class Node<E> implements Serializable 
    {
        // Data Fields

        /** The information stored in this node. */
        protected E data;
        /** Reference to the left child. */
        protected Node<E> left;
        /** Reference to the right child. */
        protected Node<E> right;

        // Constructors
        /** Construct a node with given data and no children.
            @param data The data to store in this node
        */
        public Node(E data) 
        {
            this.data = data;
            left = null;
            right = null;
        }

        // Methods
        /** Return a string representation of the node.
            @return A string representation of the data fields
        */
        public String toString () 
        {
            return data.toString();
        }
    }
    // Data Field
    /** The root of the binary tree */
    protected Node<E> root;

    /*
        Constructors:
        1- no‐parameter constructor, 
        2- a constructor that creates a tree with a given node as its root, 
        3- a constructor that builds a tree from a data value and two trees.
    */
    /** 
     * no‐parameter constructor merely sets the data field root to null
    */
    public binaryTree() 
    {
        root = null;
    }
    /** 
     * The constructor that takes a Node as a parameter
     * This is because client classes do not know about the Node class.
    */
    protected binaryTree(Node<E> root) 
    {
        this.root = root;
    }
    /** Constructs a new binary tree with data in its root leftTree
        as its left subtree and rightTree as its right subtree.
        @param data data to be referenced by the root node
        @param leftTree binaryTree that will become its left subtrees.
        @param rightTree binaryTree that will become its right subtrees.
    */
    public binaryTree(E data, binaryTree<E> leftTree, binaryTree<E> rightTree) 
    {
        root = new Node<>(data);
        if (leftTree != null) 
            root.left = leftTree.root;
        else 
            root.left = null;
        if (rightTree != null) 
            root.right = rightTree.root;
        else 
            root.right = null;
    }

    /** Return the left subtree.
        @return The left subtree or null if either the root or the left subtree is null
    */
    public binaryTree<E> getLeftSubtree() 
    {
    if (root != null && root.left != null) 
        return new binaryTree<>(root.left);
    else 
        return new binaryTree<E>(null);
    }

    /** Return the right subtree.
        @return The right subtree or null if either the root or the right subtree is null
    */
    public binaryTree<E> getRightSubtree() 
    {
    if (root != null && root.right != null) 
        return new binaryTree<>(root.right);
    else 
        return new binaryTree<E>(null);
    }

    /** Determine whether tree has any subtrees
        @return true if the root has no children
    */
    public boolean isLeaf() 
    {
        return (root.left == null && root.right == null);
    }

    /** 
        @return string representation is a preorder traversal
        If a subtree is empty, the string "null" is displayed
    */
    public String toString() 
    {
        StringBuilder sb = new StringBuilder();
        toString(root, 1, sb);
        return sb.toString();
    }

    /** Converts a sub‐tree to a string. Performs a preorder traversal.
        @param node The local root
        @param depth The depth
        @param sb The StringBuilder to save the output
    */
    private void toString(Node<E> node, int depth, StringBuilder sb) 
    {
        for (int i = 1; i < depth; i++) 
            sb.append(" ");
        if (node == null) 
            sb.append("null\n");
        else 
        {
            sb.append(node.toString());
            sb.append("\n");
            toString(node.left, depth + 1, sb);
            toString(node.right, depth + 1, sb);
        }
    }

    /** Method to read a binary tree.
        pre: The input consists of a preorder traversal of the binary tree. The line "null" indicates a null tree.
        @param scan the Scanner attached to the input file.
        @return The binary tree
    */
    public static binaryTree<String> readBinaryTree(Scanner scan) 
    {
        // Read a line and trim leading and trailing spaces.
        String data = scan.nextLine().trim();   // Remove the leading and trailing spaces
        if (data.equals("null")) 
            return null;
        else 
        {
            binaryTree<String> leftTree = readBinaryTree(scan);  // Recursively read the left child.
            binaryTree<String> rightTree = readBinaryTree(scan); // Recursively read the right child.
            return new binaryTree<>(data, leftTree, rightTree);  // Return a tree consisting of the root and the two children.
        }
    }

/*
    /** 
        @return The data in the root
    /
    public E getData()
    {
        return data;
    }
*/

    /** Performs a preorder traversal of the subtree whose root is 
        @param node
        Increments the value of
        @param depth the current tree level
        Appends the reopresentation to the
        @param sb        
    */
    private void preOrderTraverse(Node<E> node, int depth, StringBuilder sb)
    {
        for (int i = 1; i < depth; i++) 
        { 
            sb.append(" "); // indentation 
        }
        if (node == null) 
            sb.append("null\n"); 
        else 
        {
            sb.append(node.toString()); 
            sb.append("\n"); 
            preOrderTraverse(node.left, depth + 1, sb); 
            preOrderTraverse(node.right, depth + 1, sb); 
        }
    }
}