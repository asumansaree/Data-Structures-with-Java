/**
 * The class `Driver` is a driver class that runs all the methods
 */
// Importing the classes from the package `pack`.
import pack.Street;
import pack.Buildings;
import pack.House;
import pack.Office;
import pack.Market;
import pack.Playground;

/**
 * Driver class runs all the methods
 */
public class Driver
{  
    
    /** 
     * @param args
     * To put the menu simple, helper test functions are created
     */
    public static void main(String[] args)
    {
        Street side1 = new Street();
        Street side2 = new Street();
        side1.takeInput();
        side2.takeInput();
        System.out.println("MODE SELECTION TIME\n");
        editMode(side1, side2);
        System.out.println("MODE SELECTION TIME\n");
        viewMode(side1, side2);
        System.out.println("FOCUSING TIME\n");
        focusing(side1, side2);
    }  

    
    /** 
     * @param street1
     * @param street2
     */
    public static void editMode(Street street1, Street street2)
    {
        System.out.println("*************** EDIT MODE IS ACTIVE *************** \n");
        System.out.println("Constructors are TESTING for house objects...\n");
        Buildings h1 = new House(5, 5, 3, 4, "green", "Jack");  
        System.out.println("House object is created at position 5, with length 5\n");
        Buildings h2 = new House(11, 6, 5, 5, "pink", "John");
        System.out.println("House object is created at position 10, with length 6\n");
        System.out.println("Add operation TESTING for house objects...\n");
        street1.addBuilding(street1.getSide() ,h1);
        System.out.println("'h1' house object is succesfully added\n");
        street1.addBuilding(street1.getSide() ,h2);
        System.out.println("'h2' house object is succesfully added\n");
        System.out.println("Delete operation TESTING for house objects...\n");
        System.out.println("Street view before deleting house object h1: \n");
        street1.skylineSilhouette(street2); 
        System.out.println("Street view after deleting house object h1: \n");
        street1.deleteBuilding(street1.getSide() ,h1);
        street1.skylineSilhouette(street2);  
        /***********************************************/
        System.out.println("Constructors are TESTING for playground objects...\n");
        Buildings p1 = new Playground(1, 3, 1);  
        System.out.println("Playground object is created at position 1, with length 3\n");
        Buildings p2 = new Playground(18, 1, 1);
        System.out.println("Playground object is created at position 18, with length 1\n");
        System.out.println("Add operation TESTING for playground objects...\n");
        street1.addBuilding(street1.getSide() ,p1);
        System.out.println("'p1' playground object is succesfully added\n");
        street1.addBuilding(street1.getSide() ,p2);
        System.out.println("'p2' playground object is succesfully added\n");
        System.out.println("Street view after adding playground objects: \n");
        street1.skylineSilhouette(street2); 
        /***********************************************/
        System.out.println("Constructors are TESTING for office objects...\n");
        Buildings o1 = new Office(20, 7, 7, "Engineering", "Ali");  
        System.out.println("Playground object is created at position 20, with length 7\n");
        Buildings o2 = new Office(29, 4, 9, "Medicine", "Ayse");
        System.out.println("Playground object is created at position 29, with length 4\n");
        System.out.println("Add operation TESTING for office objects...\n");
        street1.addBuilding(street1.getSide() ,o1);
        System.out.println("'o1' office object is succesfully added\n");
        street1.addBuilding(street1.getSide() ,o2);
        System.out.println("'o2' office object is succesfully added\n");
        System.out.println("Street view after adding office objects: \n");
        street1.skylineSilhouette(street2); 
        /***********************************************/
        System.out.println("Constructors are TESTING for market objects...\n");
        Buildings m1 = new Market(40, 2, 2, 10.00, 15.00, "Mary");  
        System.out.println("Playground object is created at position 40, with length 2\n");
        Buildings m2 = new Market(45, 3, 9, 9.00, 19.00, "Luly");
        System.out.println("market object is created at position 45, with length 3\n");
        System.out.println("Add operation TESTING for market objects...\n");
        street1.addBuilding(street1.getSide() ,m1);
        System.out.println("'m1' market object is succesfully added\n");
        street1.addBuilding(street1.getSide() ,m2);
        System.out.println("'m2' market object is succesfully added\n");
        System.out.println("Street view after adding market objects: \n");
        street1.skylineSilhouette(street2); 
        /***********************************************/
        System.out.println("Street view before adding house object h1 to street2: \n");
        street1.skylineSilhouette(street2);
        street2.addBuilding(street2.getSide() ,h1);
        System.out.println("'h1' house object is succesfully added to street2\n");
        System.out.println("Street view after adding house object h1 to street2: \n");
        street1.skylineSilhouette(street2);
        System.out.println("*************** EDIT MODE IS TESTED FULLY *************** \n");
    }

    
    /** 
     * @param street1
     * @param street2
     */
    public static void viewMode(Street street1, Street street2)
    {
        System.out.println("*************** VIEW MODE IS ACTIVE *************** \n");

        System.out.println("'total remaining length of lands' operation TESTING...\n");
        street1.totalRemainingLen();

        System.out.println("'the list of buildings' operation TESTING...\n");
        street1.listOfBuildings(street2);

        System.out.println("'number and ratio of length of playgrounds' operation TESTING...\n");
        street1.playgroundInfo(street2);

        System.out.println("'total length of street occupied' operation TESTING...\n");
        street1.occupiedLength();

        System.out.println("'skyline silhouette' operation TESTING...\n");
        street1.skylineSilhouette(street2);  

        System.out.println("\n\n*************** VIEW MODE IS TESTED FULLY *************** \n");
    }


    
    /** 
     * @param street1
     * @param street2
     * Each kind of building instances are focused. 
     * Buildings are selected by taking indexes. 
     */
    public static void focusing(Street street1, Street street2)
    {
        System.out.println("*************** FOCUSING IS ACTIVE *************** \n");

        // print street
        System.out.println("Focusing house is TESTING...\n"); 
        System.out.print("1th building ,a house, is selected. House presents its owner: "); 
        street1.getSide()[1].presentFocus(); 

        System.out.println("Focusing market is TESTING...\n");
        System.out.print("1th building ,a market, is selected. Market presents its closing time: "); 
        //street2.getSide()[1].presentFocus(); 

        System.out.println("Focusing office is TESTING...\n");
        System.out.print("2th building ,an office, is selected. Office presents its job types: "); 
        //street2.getSide()[3].presentFocus(); 

        System.out.println("Focusing playground is TESTING...\n");        
        System.out.print("2th building ,a playground, is selected. Playground presents its length: ");         
        street1.getSide()[2].presentFocus();

        System.out.println("*************** FOCUSING IS TESTED FULLY *************** \n");
    }
}

