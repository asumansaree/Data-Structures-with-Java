/**
 * The Buildings class is a superclass of the House, Market, Office, and Playground classes.
 */
package pack;

public class Buildings 
{
    int position;
    int length;
    int height;
    int orderOfBuilding; // kepts the index of building int the Building array

    public Buildings()
    {
        position = 0;
        length = 0;
        height = 0;
    }
    
    /**
     * @param pos
    */
    public Buildings(int pos)
    {
        position = pos;
        length = 0;
        height = 0;
    }

    /**
     * @param pos
     * @param len
    */
    public Buildings(int pos, int len)
    {
        position = pos;
        length = len;
        height = 0;
    }

    /**
     * @param pos
     * @param len
     * @param hei
    */
    public Buildings(int pos, int len, int hei)
    {
        position = pos;
        length = len;
        height = hei;
    }

    /**
     * @return int
    */
    public int getLenght()   {return length;}

    /**
     * @return int
    */
    public int getHeight()   {return height;}
 
    
    /**
     * @return int
    */
    public int getOrderOfBuilding()     {return orderOfBuilding;}

    /**
     * @return int
    */
    public int getPosition() {return position;}

    /**
     * @param len
    */
    public void setLenght(int len)   {length = len;}

    /**
     * @param hei
    */
    public void setHeight(int hei)   {height = hei;}

    /**
     * @param index
    */
    public void setOrderOfBuilding(int index)      {orderOfBuilding = index;}

    /**
     * @param pos
    */
    public void setPosition(int pos) {position = pos;}

    
    /** 
     * @return Buildings
     * method makes a copy of the object on which it is called.
     */
    public Buildings clone() 
    {
        int p, l, h;
        p = this.getPosition();
        l = this.getLenght();
        h = this.getHeight();
        return new Buildings(p, l, h);
    }

    
    /** 
     * @param obj
     * @return boolean
     */
    @Override
    public boolean equals(Object obj) 
    {
        // If the object is compared with itself then return true 
        if (obj == this) 
            return true;
 
        // Check if o has same class with caller object or not, null aslo returns false 
        if (this.getClass() != obj.getClass()) 
            return false;
         
        // To compare data members, typecast o to Buildings 
        Buildings temp = (Buildings) obj;
         
        // Compare the data members and return accordingly
        return (this.getPosition() == temp.getPosition() && this.getLenght() == temp.getLenght() && this.getHeight() == temp.getHeight());
    }
    
    /** 
     * @return String
     */
    @Override
    public String toString() 
    {
        System.out.println("\n\nposition: " + this.getPosition());
        System.out.println("length: " + this.getLenght());
        System.out.println("height: " + this.getHeight());
        System.out.println("orderOfBuilding: " + this.getOrderOfBuilding() + "\n\n");
        return "done";
    }

    public void presentFocus()
    {
        // According to building type, building at the taken index, focus of that building (ex: owner for house, length for playground) is presented 
        if(this instanceof House) 
            System.out.println(((House)this).getOwner()); 

        else if(this instanceof Market)
            System.out.println(((Market)this).getClosingTime()); 

        else if(this instanceof Office)
            System.out.println(((Office)this).getJobTypes()); 
        
        else if(this instanceof Playground)
            System.out.println(this.getLenght()); 
    }

/*
    @Override
    public Buildings clone() 
    {
        return new Buildings(this);
    }
*/
}