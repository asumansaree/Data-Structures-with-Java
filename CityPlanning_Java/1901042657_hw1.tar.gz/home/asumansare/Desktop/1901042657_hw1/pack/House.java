/**
 * Only toString and clone methods are changes from parent class
 */
package pack;

public class House extends Buildings
{
    private int numberOfRooms;
    private String color;
    private String owner;


    public House()
    {
        //System.out.println("Object is created by no parameter constructor\n");
        super();
        numberOfRooms = 0;
        color = "defaultColor";
        owner = "defaultOwner";   
    }
    
    /** 
     * @param pos
     */
    public House(int pos)
    {
        super(pos);
        numberOfRooms = 0;
        color = "defaultColor";
        owner = "defaultOwner";
    }

    /** 
     * @param pos
     * @param len
     */
    public House(int pos, int len)
    {
        //System.out.println("Object is created by constructor that takes all values as parameter\n");
        super(pos, len);
        numberOfRooms = 0;
        color = "defaultColor";
        owner = "defaultOwner";
    }

    /** 
     * @param pos
     * @param len
     * @param hei
     */
    public House(int pos, int len, int hei)
    {
        //System.out.println("Object is created by constructor that takes all values as parameter\n");
        super(pos, len, hei);
        numberOfRooms = 0;
        color = "defaultColor";
        owner = "defaultOwner";
    }

    /** 
     * @param pos
     * @param len
     * @param hei
     * @param nor
     * @param col
     * @param own
     */
    public House(int pos, int len, int hei, int nor, String col, String own)
    {
        //System.out.println("Object is created by constructor that takes all values as parameter\n");
        super(pos, len, hei);
        numberOfRooms = nor;
        color = col;
        owner = own;
    }

    
    /** 
     * @return int
     */
    // tek basina bir setHouse methodu olustur, setter getterlari burada calistir

    public int getNumberOfRooms()
    {
        return numberOfRooms;
    }

    
    /** 
     * @return String
     */
    public String getColor()
    {
        return color;
    }

    
    /** 
     * @return String
     */
    public String getOwner()
    {
        return owner;
    }

    
    /** 
     * @param roomNumber
     */
    public void setNumberOfRooms(int roomNumber)
    {
        numberOfRooms = roomNumber;
    }

    
    /** 
     * @param col
     */
    public void setColor(String col)
    {
        color = col;
    }

    
    /** 
     * @param own
     */
    public void setOwner(String own)
    {
        owner = own;
    }

    
    /** 
     * @return String
     */
    @Override
    public String toString() 
    {
        // TODO Auto-generated method stub
        return super.toString() + "numberOfRooms: " + this.getNumberOfRooms() + "color: " + this.getColor() + "owner: " + this.getOwner();
    }

    
    /** 
     * @return int
     */
    @Override
    public int hashCode() 
    {
        return super.hashCode();
    }

    
    /** 
     * @param obj
     * @return boolean
     */
    @Override
    public boolean equals(Object obj) 
    {
        if (obj == this) 
            return true;
 
        // Check if o has same class with caller object or not, null aslo returns false 
        if (this.getClass() != obj.getClass()) 
            return false;
         
        // To compare data members, typecast o to Buildings 
        House temp = (House) obj;
         
        // Compare the data members and return accordingly
        return (this.getColor() == temp.getColor() && this.getNumberOfRooms() == temp.getNumberOfRooms() && this.getOwner() == temp.getOwner());
    }

    
}