/**
 * Only toString and clone methods are changes from parent class
 */
package pack;


public class Market extends Buildings
{
    double openingTime;
    double closingTime;
    String owner;

    public Market()
    {
        //System.out.println("Object is created by no parameter constructor\n");
        super();
        openingTime =0.0;
        closingTime =1.0;
        owner = "defaultOwner";   
    }
    
    /** 
     * @param pos
     */
    public Market(int pos)
    {
        super(pos);
        openingTime =0.0;
        closingTime =1.0;
        owner = "defaultOwner"; 
    }

    /** 
     * @param pos
     * @param len
     */
    public Market(int pos, int len)
    {
        //System.out.println("Object is created by constructor that takes all values as parameter\n");
        super(pos, len);
        openingTime =0.0;
        closingTime =1.0;
        owner = "defaultOwner"; 
    }

    /** 
     * @param pos
     * @param len
     * @param hei
     */
    public Market(int pos, int len, int hei)
    {
        //System.out.println("Object is created by constructor that takes all values as parameter\n");
        super(pos, len, hei);
        openingTime =0.0;
        closingTime =1.0;
        owner = "defaultOwner"; 
    }

    /** 
     * @param pos
     * @param len
     * @param hei
     * @param open
     * @param close
     * @param own
     */
    public Market(int pos, int len, int hei, double open, double close, String own)
    {
        //System.out.println("Object is created by constructor that takes all values as parameter\n");
        super(pos, len, hei);
        openingTime = open;
        closingTime = close;
        owner = own; 
    }

    
    /** 
     * @return double
     */
    public double getClosingTime()
    {
        return closingTime;
    }

    
    /** 
     * @return double
     */
    public double getOpeningTime()
    {
        return openingTime;
    }

    
    /** 
     * @return String
     */
    public String getOwner()
    {
        return owner;
    }

    
    /** 
     * @return int
     */
    @Override
    public int hashCode() 
    {
        return super.hashCode();
    }

    
    /** 
     * @param obj
     * @return boolean
     */
    @Override
    public boolean equals(Object obj) 
    {
        if (obj == this) 
            return true;
 
        // Check if o has same class with caller object or not, null aslo returns false 
        if (this.getClass() != obj.getClass()) 
            return false;
         
        // To compare data members, typecast o to Buildings 
        Market temp = (Market) obj;
         
        // Compare the data members and return accordingly
        return (this.getClosingTime() == temp.getClosingTime() && this.getOpeningTime() == temp.getOpeningTime() && this.getOwner() == temp.getOwner());
    }

    
    /** 
     * @return String
     */
    @Override
    public String toString() 
    {
        return super.toString() + "openingTime: " + openingTime + "closingTime: " + closingTime + "owner: " + owner; 
    }

    
    /** 
     * @return Market
     */
    @Override
    public Market clone() 
    {
        return (Market)super.clone();
    }
}