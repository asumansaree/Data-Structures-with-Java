/**
 * Only toString and clone methods are changes from parent class
 */
package pack;

public class Office extends Buildings
{
    String jobType;
    String owner;

    public Office()
    {
        //System.out.println("Object is created by no parameter constructor\n");
        super();
        jobType = "defaultJobType";
        owner = "defaultOwner";   
    }
    
    /** 
     * @param pos
     */
    public Office(int pos)
    {
        super(pos);
        jobType = "defaultJobType";
        owner = "defaultOwner";   
    }

    /** 
     * @param pos
     * @param len
     */
    public Office(int pos, int len)
    {
        //System.out.println("Object is created by constructor that takes all values as parameter\n");
        super(pos, len);
        jobType = "defaultJobType";
        owner = "defaultOwner";   
    }

    /** 
     * @param pos
     * @param len
     * @param hei
     */
    public Office(int pos, int len, int hei)
    {
        //System.out.println("Object is created by constructor that takes all values as parameter\n");
        super(pos, len, hei);
        jobType = "defaultJobType";
        owner = "defaultOwner";   
    }

    /** 
     * @param pos
     * @param len
     * @param hei
     * @param jobT
     * @param own
     */
    public Office(int pos, int len, int hei, String jobT, String own)
    {
        //System.out.println("Object is created by constructor that takes all values as parameter\n");
        super(pos, len, hei);
        jobType = jobT;
        owner = own;   
    }

    
    /** 
     * @return String
     */
    public String getJobTypes()
    {
        return jobType;
    }

    
    /** 
     * @return String
     */
    public String getOwner()
    {
        return owner;
    }

    
    /** 
     * @return int
     */
    @Override
    public int hashCode() 
    {
        return super.hashCode();
    }

    
    /** 
     * @return String
     */
    @Override
    public String toString() 
    {
        return super.toString() + "jobType: " + this.getJobTypes() + "owner: " + this.getOwner();
    }

    
    /** 
     * @param obj
     * @return boolean
     */
    @Override
    public boolean equals(Object obj) 
    {
        if (obj == this) 
            return true;
 
        // Check if o has same class with caller object or not, null aslo returns false 
        if (this.getClass() != obj.getClass()) 
            return false;
         
        // To compare data members, typecast o to Buildings 
        Office temp = (Office) obj;
         
        // Compare the data members and return accordingly
        return (this.getJobTypes() == temp.getJobTypes() && this.getOwner() == temp.getOwner());
    }

    
    /** 
     * @return Office
     */
    @Override
    public Office clone() 
    {
        return (Office)super.clone();
    }
}