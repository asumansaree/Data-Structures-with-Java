/**
 * It extends Buildings 
 * There is no need for override any method, playground is just same as normal building
 * without extra properties
 */
package pack;

public class Playground extends Buildings
{
    public Playground()                             {super();}
    
    public Playground(int pos)                      {super(pos);}

    public Playground(int pos, int len)             {super(pos, len);}

    public Playground(int pos, int len, int hei)    {super(pos, len, hei);}

    
    /** 
     * @return int
     */
    @Override
    public int hashCode() 
    {
        return super.hashCode();
    }

    
    /** 
     * @param obj
     * @return boolean
     */
    @Override
    public boolean equals(Object obj) 
    {
        return super.equals(obj);
    }

    
    /** 
     * @return String
     */
    @Override
    public String toString() 
    {
        return super.toString();
    }

    
    /** 
     * @return Playground
     */
    @Override
    public Playground clone() 
    {
        return (Playground)super.clone();
    }
}