package pack;

/**
 * Street is a class constructed from Building class' objects 
 * @author Asuman Sare ERGUT
 */

public class Street
{  
    /**
        field part
    */
    private int streetLen;
    private int numberOfBuildings=0;
    private int[] position; 
    private int[] countInstances; //0th index is for house, 1th index is for market, 2th index is for office and 3th index is for playground instances

    private Buildings[] side = null; 

    public void takeInput()
    {
        this.setStreetLen(50);
        this.setDefaultPositions();
        this.setCountInstancesInit();
    }

    
    /** 
     * @param side takes side array and adds
     * @param obj incoming object to that array
     */
    public void addBuilding(Buildings[] side, Buildings obj)
    {
        if(this.isEnoughLand(obj.getPosition(), obj.getLenght()) == true)
        {
            // null ekle
            Buildings[] temp = new Buildings[this.getNumberOfBuildings()+1];
            if(side == null)
                side = new Buildings[1];
            for (int i=0; i<this.getNumberOfBuildings(); ++i)
            {
                temp[i] = side[i];
            }
            if(obj instanceof House)
                temp[temp.length-1] = (House)obj;
            else if(obj instanceof Market)
                temp[temp.length-1] = (Market)obj;
            else if(obj instanceof Office)
                temp[temp.length-1] = (Office)obj;
            else if(obj instanceof Playground)
                temp[temp.length-1] = (Playground)obj;
            editPositionArray(obj.getPosition(), obj.getLenght(), obj.getHeight());
            setSide(temp);
            ++numberOfBuildings;
        }
        else
            System.out.println(" There is no enough land in position " + obj.getPosition() + " for adding " + obj.getLenght() + " lenght ");
    }
    
    
    /** 
     * @param side takes side array and 
     * @param obj name of the building object will be come to the delete function as parameter 
     */
    public void deleteBuilding(Buildings[] side, Buildings obj)
    {
        // First condition for deleting a building is existance of that building. So that it shouldn't seen as "empty area", should occupy a space.
        // That's why I'm first checked whether isEnoughLand returns false
        if(this.isEnoughLand(obj.getPosition(), obj.getLenght()) == false)
        {
            Buildings[] temp = new Buildings[this.getNumberOfBuildings()-1];
            for (int i=0; i<this.getNumberOfBuildings(); ++i)
            {
                if (this.getSide()[i].equals(obj)) // in case equals method returns true, copy that item
                    temp[i] = this.getSide()[i].clone();
            }
            editPositionArray(obj.getPosition(), obj.getLenght(), 0); // deleted buildings will be count as building that has height 0
            setSide(temp);
            --numberOfBuildings;
        }
        else
            System.out.println(" There is no building in position " + obj.getPosition() + " for deleting ");
    }

    /**
     * It increments the countInstances array by 1 if the object is an instance of the House, Market,
     * Office, or Playground classes.
     * 
     * @param obj The object that is being added to the list.
     */
    public void setCountInstances(Buildings obj)
    {
        if(obj instanceof House)
            ++countInstances[0];
        else if(obj instanceof Market)
            ++countInstances[1];
        else if(obj instanceof Office)
            ++countInstances[2];
        else if(obj instanceof Playground)
            ++countInstances[3];
    }   

    /**
     * Just to initialize the array
     */
    public void setCountInstancesInit()   
    {
        if(countInstances == null)
            countInstances = new int[4];
        for(int i=0; i<4; ++i) 
            countInstances[i] = 0;
    }

    public void setStreetLen(int len) {streetLen = len;}   

    public int getStreetLen()               {return streetLen;}

    public int getNumberOfBuildings()       {return numberOfBuildings;}

    public int getCountInstances(int index) {return countInstances[index];}

    public void setSide(Buildings[] obj)   {side = obj;}

    public Buildings[] getSide()           {return side;}

    public int[] getPosition()              {return position;}

    public void setPosition(int[] obj)   {position = obj;}

    
    /** 
     * @param pos array is an int array
     */
    public void positionPrint(int[] pos)
    {
        for(int i=0; i<pos.length; ++i)
            System.out.print(pos[i]);
        System.out.println("\n");
    }

    /**
     * Just to initialize the array
     */
    public void setDefaultPositions()
    {
        // Position info is kept as integers
        int[] tempPos = new int[this.getStreetLen()+1];

        for(int i=0; i<this.getStreetLen(); ++i)
        {
            tempPos[i] = 0;
        }
        setPosition(tempPos);
    }


    
    /** 
     * @param pos takes this and
     * @param len this, and looks whether a building can be placed at a land on the street 
     * @return boolean
     */
    public boolean isEnoughLand(int pos, int len)
    {
        // first control whether it exceed the street lenght or not
        if(pos+len > this.getStreetLen())
            return false;
        for(int i=pos; i<pos+len; ++i)
        {
            if(this.getPosition()[i] != 0)
                return false;
        }
        return true;
    }

    
    /** 
     * @param pos
     * @param len
     * @param hei
     * to edit the given array
     */
    public void editPositionArray(int pos, int len, int hei)
    {
        for (int i=pos; i<pos+len; ++i) 
        {
            this.getPosition()[i] = hei;  
        }
    }

    /** 
     * func that Display the total remaining length of lands
     */
    public void totalRemainingLen() 
    {
        int totalRemaining = 0;
        for(int i=0; i<this.getStreetLen(); ++i)
        {
            if(getPosition()[i] == 0)
                ++totalRemaining;
        }
        System.out.println("Total remaining length of lands: " + totalRemaining);
    }

    
    /** 
     * @param street2 Both prints street1 and street2's buildings and their amounts
     */
    public void listOfBuildings(Street street2)
    {
        // func that Display the list of buildings
        int[] positions = new int[this.getNumberOfBuildings()];
        for(int i=0; i<this.getNumberOfBuildings(); ++i)
        {
            positions[i] = this.getSide()[i].getPosition();
        }
        System.out.println("The list of buildings - SIDE 1 :\n ");
        for(int i=0; i<this.getNumberOfBuildings(); ++i) 
        {
            String str = findInstanceOf(this.getSide()[i]);
            int searchPos = orderToPosition(positions, i);
            System.out.print((i+1) + "th building is: " + findInstanceOf(searchPosition(searchPos)) + "\n"); 
            this.setCountInstances(this.getSide()[i]);
        }
        System.out.println("\nThere are " + countInstances[0] + " house");
        System.out.println("There are " + countInstances[1] + " market");
        System.out.println("There are " + countInstances[2] + " office");
        System.out.println("There are " + countInstances[3] + " playground");


        positions = new int[street2.getNumberOfBuildings()];
        for(int i=0; i<street2.getNumberOfBuildings(); ++i)
        {
            positions[i] = street2.getSide()[i].getPosition();
        }
        System.out.println("The list of buildings - SIDE 2 :\n ");
        for(int i=0; i<street2.getNumberOfBuildings(); ++i) 
        {
            String str = findInstanceOf(street2.getSide()[i]);
            int searchPos = orderToPosition(positions, i);
            System.out.print((i+1) + "th building is: " + findInstanceOf(searchPosition(searchPos)) + "\n"); 
            street2.setCountInstances(street2.getSide()[i]);
        }
        System.out.println("\nThere are " + street2.countInstances[0] + "house");
        System.out.println("There are " + street2.countInstances[1] + "market");
        System.out.println("There are " + street2.countInstances[2] + "office");
        System.out.println("There are " + street2.countInstances[3] + "playground");
    } 

    
    /** 
     * @param pos
     * @return Buildings searches for to which object incoming pos value is belong
     */
    public Buildings searchPosition(int pos)
    {
        for(int i=0; i<this.getNumberOfBuildings(); ++i)
        {
            if(this.getSide()[i].getPosition() == pos)
            {
                return this.getSide()[i];
            }
        }
        return new Buildings(0, 0, 0);
    }

    
    /** 
     * @param positionsArr
     * @param index
     * @return int
     * Puts in order the position values
     */
    public int orderToPosition(int[] positionsArr, int index)
    {
        for (int i=0; i<positionsArr.length; ++i)   
        {  
            for (int j=i+1; j<positionsArr.length; ++j)   
            {  
                int temp = 0;  
                if (positionsArr[i] > positionsArr[j])   
                {  
                    temp = positionsArr[i];  
                    positionsArr[i] = positionsArr[j];  
                    positionsArr[j] = temp; 
                } 
            }  
        } 
        return positionsArr[index];
    }

    
    /** 
     * @param street2
     * func that Display the number and ratio of length of playgrounds
     */
    public void playgroundInfo(Street street2)
    {
        int sum = 0;
        System.out.println("There are " + countInstances[3] + " playgrounds");
        for(int i=0; i<this.getNumberOfBuildings(); ++i)
        {
            if (this.getSide()[i] instanceof Playground)
            {
                sum += this.getSide()[i].getLenght();
            }
        }
        for(int i=0; i<street2.getNumberOfBuildings(); ++i)
        {
            if (street2.getSide()[i] instanceof Playground)
                sum += street2.getSide()[i].getLenght();
        }
        System.out.println("Total length of the playgrounds " + sum);
        System.out.println("Ratio of the playgrounds " + (double)sum / (double)streetLen);

    }

    /** 
     * @param street2
     * func that Calculate the total length of street occupied by the markets, houses or offices
     */
    public void occupiedLength()
    {
        int totalOccupied = 0;
        for(int i=0; i<this.getStreetLen(); ++i)
        {
            if(getPosition()[i] != 0)
                ++totalOccupied;
        }
        System.out.println("Total length of street occupied by the markets, houses or offices is: " + totalOccupied);

    }

    
    /** 
     * @param street2
     * @throws ArrayIndexOutOfBoundsException
     * Types of buildings are useless for this print function. It cares about position, length and height
     */
    public void skylineSilhouette(Street street2) throws ArrayIndexOutOfBoundsException
    {
        int maxHeight = this.findMaxHeight(street2);
        System.out.println("max height: " + maxHeight);
        System.out.println("street len: " + this.getStreetLen());
        char sketchArr[][] = new char[maxHeight+1][this.getStreetLen()];
        for(int i=0; i<this.getStreetLen(); ++i)
        {
            int colHeight;
            if(this.getPosition()[i] > street2.getPosition()[i]) // find the bigger height in case they are collapse
                colHeight = this.getPosition()[i];
            else
                colHeight = street2.getPosition()[i];
            for(int j=maxHeight; j>=(maxHeight- colHeight); --j)
            {
                sketchArr[j][i] = '#';
            }
        }
        for(int i=0; i<this.getStreetLen(); ++i)
            sketchArr[maxHeight][i] = '_';
        for(int i=0; i<this.getStreetLen(); ++i)
            System.out.print("_");
        System.out.print("\n");
        for(int i=0; i<=maxHeight; ++i)
        {
            for(int j=0; j<this.getStreetLen(); ++j)
            {
                if(sketchArr[i][j] == '#' || sketchArr[i][j] == '_')
                    System.out.print(sketchArr[i][j]);
                else
                    System.out.print(" ");                    
            }
            System.out.print("\n");
        }
        System.out.print("0");
        for(int i=1; i<this.getStreetLen()-1; ++i)
            System.out.print(" ");
        System.out.print(this.getStreetLen() + "\n");
    }

    
    /** 
     * @param street2
     * @return int
     */
    public int findMaxHeight(Street street2)
    {
        int tempMax1 = this.getPosition()[0];
        int tempMax2 = street2.getPosition()[0];
        for(int i=1; i<this.getStreetLen(); ++i)
        {
            if(this.getPosition()[i] > tempMax1)
                tempMax1 = this.getPosition()[i];
            if(street2.getPosition()[i] > tempMax1)
                tempMax2 = street2.getPosition()[i];
        } 
        if(tempMax2 >= tempMax1)
            tempMax1 = tempMax2;
        return tempMax1;
    }

    /** 
     * @param obj
     * @return String tells object to which instance belong to
     */
    public String findInstanceOf(Buildings obj)
    {
        if(obj instanceof House)
            return "House"; 
        else if(obj instanceof Market)
            return "Market"; 
        else if(obj instanceof Office)
            return "Office"; 
        else if(obj instanceof Playground)
            return "Playground"; 
        else 
            return "none"; 
    }
}



