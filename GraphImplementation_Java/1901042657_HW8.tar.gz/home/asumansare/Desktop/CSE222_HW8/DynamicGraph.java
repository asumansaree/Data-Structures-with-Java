import java.util.*;
import java.io.*;


/** 
 * Interface to specify a dynamic graph. 
*/

public interface DynamicGraph
{
    // Accessor Methods
    /** Return the number of vertices.
        @return The number of vertices
    */
    int getNumV();

    /** Determine whether this is a directed graph.
        @return true if this is a directed graph
    */
    boolean isDirected();

    /** Insert a new edge into the graph.
        @param edge The new edge
    */
    void insert(Edge edge);

    /** Determine whether an edge exists.
        @param source The source vertex
        @param dest The destination vertex
        @return true if there is an edge from source to dest
    */
    boolean isEdge(int source, int dest);

    /** Get the edge between two vertices.
        @param source The source vertex
        @param dest The destination vertex
        @return The Edge between these two vertices
              or an Edge with a weight of
              Double.POSITIVE_INFINITY if there is no edge
    */
    Edge getEdge(int source, int dest);

    /** Return an iterator to the edges connected
        to a given vertex.
        @param source The source vertex
        @return An Iterator<Edge> to the vertices
              connected to source
    */
    Iterator < Edge > edgeIterator(int source);

        /** Generate a new vertex by given parameters.
    */
	void newVertex(String label, double weight);

    /** Add the given vertex to the graph.
     *  Return true in case of successful adding and false otherwise. 
    */
	Vertex addVertex(Vertex new_vertex);

    /** Add an edge between the given two vertices in the graph.
      * Return true if adding an edge is possible and false otherwise.
    */
	boolean addEdge(int vertexID1, int vertexID2, double weight);

    /** Remove the edge between the given two vertices.
    */
	void removeEdge (int vertexID1, int vertexID2);

    /** Remove the vertex from the graph with respect to the given vertex id.
     *  Returns the removed vertex
    */
	Vertex removeVertex (int vertexID);

    /** Remove the vertices that have the given label from the graph.
      * Returns the removed vertex
    */
	void removeVertex (String label);

    /** Print the graph in adjacency list format
    */
	void printGraph();


    /** Filter the vertices by the given user-defined property and returns a subgraph of the graph.
    */
    MyGraph filterVertices (String key, String filter);

    /** Generate the adjacency matrix representation of the graph and returns the matrix.
    */
    double[][] exportMatrix();

}
