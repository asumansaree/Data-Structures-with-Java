import java.util.*;
import java.io.*;

/** 
 * MyGraph class for the implementation of DynamicGraph interface. 
 * Adjacency list representation is used to handle the edges between vertices in the graph data structure.
*/

public class MyGraph implements DynamicGraph
{

    // Data Field
    /** An array of Lists to contain the edges that
      originate with each vertex. */
    private LinkedList < Edge > [] edges;
    private int vertexCount = 0;
    private LinkedList <Vertex> vertices;
    /** Flag to indicate whether this is a directed graph */
    private boolean directed;
    /** The number of vertices */
    private int numV;

  /** Construct a graph with the specified number of
      vertices and directionality.
      @param numV The number of vertices
      @param directed The directionality flag
   */
  @SuppressWarnings("unchecked")
  public MyGraph(int numV, boolean _directed) {
    // super(numV, directed);
    directed = _directed;
    edges = new LinkedList[numV];
    vertices = new LinkedList<Vertex>();
    for (int i = 0; i < numV; i++) {
      edges[i] = new LinkedList < Edge > ();
      vertices.add(new Vertex(i));
    }
    //System.out.println("size: " + vertices.size());
  }


  /** Determine whether an edge exists.
      @param source The source vertex
      @param dest The destination vertex
      @return true if there is an edge from source to dest
   */
  public boolean isEdge(int source, int dest) {
    return edges[source].contains(new Edge(source, dest));
  }

  /** Insert a new edge into the graph.
      @param edge The new edge
   */
  public void insert(Edge edge) 
  {
    addEdge(edge.getSource(), edge.getDest(), edge.getWeight());
  }

  /** Return the number of vertices.
        @return The number of vertices
    */
    public int getNumV()
    {
        return vertexCount;
    }

  public boolean isDirected()
  {
    return directed;
  }

  public Iterator < Edge > edgeIterator(int source) {
    return edges[source].iterator();
  }

  /** Get the edge between two vertices. If an
      edge does not exist, an Edge with a weight
      of Double.POSITIVE_INFINITY is returned.
      @param source The source
      @param dest The destination
      @return the edge between these two vertices
   */
  public Edge getEdge(int source, int dest) {
    Edge target =
        new Edge(source, dest, Double.POSITIVE_INFINITY);
    for (Edge edge : edges[source]) {
      if (edge.equals(target))
        return edge; // Desired edge found, return it.
    }
    // Assert: All edges for source checked.
    return target; // Desired edge not found.
   }


    public void increaseVertexAmount()
    {
        ++vertexCount;
    }

    /** Determine whether a vertex exists.
      @param source The source vertex
      @return true if there is vertex 
    */
    public boolean isVertex(Vertex vertex) 
    {
      return vertices.contains(new Vertex(vertex.getIndexID(),
                                vertex.getLabel(),
                                vertex.getWeight()));
    }

    /** Generate a new vertex by given parameters.
    */
    public void newVertex(String label, double weight)
    {
        long t0 = System.nanoTime();
        vertices.add(new Vertex(vertexCount, label, weight)); // Generate new vertex by calling its constructor
        // After adding one vertex, field that counts vertex amount should be increased.
        increaseVertexAmount();
        long t1 = System.nanoTime();
        long diff = t1 - t0;
        System.out.println("Overall execution time for newVertex(): " + diff);

    }

    /** Add the given vertex to the graph.
     *  Return true in case of successful adding and false otherwise. 
    */
      @SuppressWarnings("unchecked")

    public Vertex addVertex(Vertex new_vertex) 
    {
        long t0 = System.nanoTime();
        //int index = new_vertex.getIndexID();
        //vertices.set(index, new_vertex);
        vertices.add(new_vertex);
        LinkedList < Edge > [] old = edges;
        //System.out.println("edges.length: " + edges.length);
           edges = new LinkedList[edges.length+1];
        // System.out.println("edges.length: " + edges.length);
        for (int i = 0; i < edges.length-1; i++) {
            edges[i] = old[i];
        }
        edges[edges.length-1    ] = new LinkedList<Edge>();
        long t1 = System.nanoTime();
        long diff = t1 - t0;
        // System.out.println("Overall execution time for addVertex(): " + diff);
        return vertices.getLast();
    }

    /** Add an edge between the given two vertices in the graph.
      * Return true if adding an edge is possible and false otherwise.
    */
    public boolean addEdge(int vertexID1, int vertexID2, double weight)
    {
        // Before adding coming edge to graph between the given two vertices, 
        // control whether those vertices are exists with isVertex() method 
        long t0 = System.nanoTime();     
        boolean retVal;   
        if(!(isVertex(vertices.get(vertexID1)) && isVertex(vertices.get(vertexID2))))
            retVal = false;
        else 
        {
            edges[vertexID1].add(new Edge(vertexID1, vertexID2, weight));     // Construct a weighted edge from vertexID1 to vertexID2, with weight.
            if (!isDirected())
                edges[vertexID2].add(new Edge(vertexID2, vertexID1, weight)); // source and destination is changed
            retVal = true;
        }
        long t1 = System.nanoTime();
        long diff = t1 - t0;
        //System.out.println("Overall execution time for addEdge(): " + diff);
        return retVal;
    }

    /** Remove the edge between the given two vertices.
    */
    public void removeEdge (int vertexID1, int vertexID2)
    {
        long t0 = System.nanoTime();     
        // First control the validity of the vertices
        if(isVertex(vertices.get(vertexID1)) && isVertex(vertices.get(vertexID2)))
        {
            edges[vertexID1].remove(new Edge(vertexID1, vertexID2));     
        // remove with index parameter
            edges[vertexID2].remove(new Edge(vertexID1, vertexID2));  
        }
        long t1 = System.nanoTime();
        long diff = t1 - t0;
        // System.out.println("Overall execution time for removeEdge(): " + diff);
 
    }

    /** Remove the vertex from the graph with respect to the given vertex id.
     *  Returns the removed vertex
    */
    public Vertex removeVertex (int vertexID)
    {
        long t0 = System.nanoTime();     
        // Don't completely remove the vertex, not to override the indexID.
        // Assign a dummy value as index to be removed position
        Vertex oldVertex = vertices.get(vertexID); 
        vertices.remove(vertexID);
        long t1 = System.nanoTime();
        long diff = t1 - t0;
        // System.out.println("Overall execution time for removeVertex (int vertexID): " + diff);
        return oldVertex;
 
    }

    /** Remove the vertices that have the given label from the graph.
    */
    public void removeVertex (String label)
    {
        long t0 = System.nanoTime();     
        for(Vertex v : vertices)
        {
            if((v.getLabel()).equals(label))
                vertices.remove(v.getIndexID()); // remove by index
        }
        long t1 = System.nanoTime();
        long diff = t1 - t0;
        System.out.println("Overall execution time for removeVertex (String label): " + diff);
    }

    /** Print the graph in adjacency list format
    */
    public void printGraph()
    {
        long t0 = System.nanoTime();     
        for(int i=0; i<vertices.size(); i++)
        {
          System.out.println("\nGraph: "+ vertices.get(i) + "\nEdges: ");
            for(int j=0; j<edges[i].size(); j++)
            {
              System.out.print(edges[i].get(j));
            }
        }
        long t1 = System.nanoTime();
        long diff = t1 - t0;
        //System.out.println("Overall execution time for printGraph(): " + diff);
    }

    public void fullPrinting()
    {
        for(int i=0; i<vertices.size(); i++)
        {
            System.out.print("\n\nSub-Graph: "+ vertices.get(i) + "\nEdges: ");
            for(int j=0; j<edges[i].size(); j++)
            {
              System.out.print(edges[i].get(j));
            }
            System.out.println("\nKey-Value Pairs: \n" + vertices.get(i).getKVPairs());
        }
    }

    /** 
      * Ask for user-defined property and add them to vertex
    */
    public void addUserDefProperty(String key, String filter, Vertex new_vertex)
    {
        (new_vertex).setKVPairs(key, filter);
    }

    /** 
      * Filter the vertices by the given user-defined property and returns a subgraph of the graph.
    */
    public MyGraph filterVertices(String key, String filter)
    {
        long t0 = System.nanoTime();     
        MyGraph tempGraph = new MyGraph(vertices.size(), false);
        //for(Vertex v : vertices)
    //        System.out.println("vertices.size(): "+vertices.size()); 
        for(int i=0; i<vertices.size(); i++)
        {
            //System.out.println("1((vertices.get(i)).printMap()): " );
            //System.out.println("2((vertices.get(i)).getKVPairs()).get(key): " + ((vertices.get(i)).getKVPairs(key)));
            // System.out.println("3filter: " + filter);
            if(vertices.get(i).getKVPairs(key) != null)
            {
             System.out.println("\nVertexID that has intended Key-Value Pair: "+ vertices.get(i));
                if(((vertices.get(i)).getKVPairs(key)).equals(filter))
                {
                    tempGraph.addVertex((vertices.get(i)));
                    // tempGraph.printGraph();
                    System.out.println("edges of that vertex: " + this.edges[(vertices.get(i).getIndexID())]);
                    for(int j=0; j<edges[(vertices.get(i).getIndexID())].size(); ++j)
                    {
                        //System.out.println("edges[(vertices.get(i).getIndexID())].get(j): " + edges[(vertices.get(i).getIndexID())].get(j));
                        //System.out.println("tempGraph.edges[j]: " + tempGraph.edges[i]);
                        tempGraph.edges[i].add(edges[(vertices.get(i).getIndexID())].get(j)) ;
                        System.out.println("= User Defined Properties =");
                        (vertices.get(i)).printMap();  

                    }
                }
            }
        }
        long t1 = System.nanoTime();
        long diff = t1 - t0;
        System.out.println("Overall execution time for filterVertices(): " + diff);
        return tempGraph;
    }

    /** Method that takes 
      @param myGraph a MyGraph object and
      @param vertex a vertex
      as a parameter to perform a modified version of Dijkstra’s Algorithm 
      for calculating the shortest paths from the given vertex to all other vertices in the graph. 
      @return true if there is vertex 
    */
    public static void  modifiedDijkstra(MyGraph myGraph, Vertex vertex)
    {
      int numV = myGraph.vertices.size();
      int startVertex = vertex.getIndexID();
      ArrayList<Integer> otherVertices = new ArrayList(); 
      int selectedVertex = startVertex;
      ArrayList<Integer> pred = new ArrayList(); 
      ArrayList<Double> dist = new ArrayList();
      //System.out.println(startVertex + "th index is selected as startVertex");

      for (int i = 0; i < numV; ++i) 
      {
        //System.out.println("i: " + i + " otherVertices[i]: " + otherVertices.get(i));
        if (i != 0) 
          otherVertices.add(i);
      }
        //System.out.println("otherVertices: " + otherVertices);

      // Initialize pred and dist.
      for (int v : otherVertices) 
      {
        pred.add(startVertex);
        dist.add(myGraph.getEdge(startVertex, v).getWeight());
      }
        //System.out.println("pred1: " + pred);
        //System.out.println("dist1: " + dist);

      while (otherVertices.size() != 0) 
      {
        //System.out.println("pred: " + pred);
        //System.out.println("dist: " + dist);
        // Find the value u in V–S with the smallest dist[u].
        double minDist = Double.POSITIVE_INFINITY;
        int u = -1;
        for (int v : otherVertices) 
        {
          if (dist.get(v) < minDist) 
          {
            minDist = dist.get(v);
            u = v;
          }
        }

        // Remove u from otherVertices
        otherVertices.remove(u);
        // Update the distances.
        for (int v : otherVertices) 
        {
            if (myGraph.isEdge(u, v)) 
            {
                double weight = myGraph.getEdge(u, v).getWeight();
                String boosting = myGraph.vertices.get(v).getKVPairs("boostingValue");
                if (dist.get(u) + weight < dist.get(v)) 
                {
                    dist.set(v, (dist.get(u)+weight));
                    pred.set(v, u);
                    // System.out.println("Array values are as follows: " + dist);
                    // System.out.println("Smallest index is at vertex id " + v);
                }
            }
        }
      }
    }

    /** 
     * Generate the adjacency matrix representation of the graph and returns the matrix.
    */
    public double[][] exportMatrix()
    {
        long t0 = System.nanoTime();
        int arrSize = vertices.size();
        double[][] returnMatrix = new double[arrSize][arrSize];

        for (double[] arr : returnMatrix)
            Arrays.fill(arr, Double.POSITIVE_INFINITY);

        for (int i = 0; i < returnMatrix.length; ++i)
        {
            int count = 0;
            for (Edge edge : edges[i])
            {
                returnMatrix[i][count] = edge.getWeight();
                ++count;
            }
        }
        long t1 = System.nanoTime();
        long diff = t1 - t0;
        System.out.println("\nOverall execution time for exportMatrix(): " + diff);
        for(int i = 0; i<arrSize; ++i)
        {
            for(int j=0; j<arrSize; ++j)
            {
                if(returnMatrix[i][j] == Double.POSITIVE_INFINITY)
                    System.out.print(" " + "INF" + "   ");
                else 
                    System.out.print(" " + returnMatrix[i][j] + "   ");
            }
            System.out.println("");
        }
        return returnMatrix;
    }

    /** Load the edges of a graph from the data in an input file.
        The file should contain a series of lines, each line
        with two or three data values. The first is the source
        the second is the destination, and the optional third
        is the weight
        @param bufferedReader The BufferedReader that is connected
                              to the file that contains the data
        @throws IOException - If an I/O error occurs
   */
    public void loadEdgesFromFile(BufferedReader bufferedReader) throws IOException 
    {
        String line;
        while ( (line = bufferedReader.readLine()) != null && line.length() != 0) 
        {
          Scanner sc = new Scanner(line);
          int source = sc.nextInt();
          int dest = sc.nextInt();
          double weight = 1.0;
          if (sc.hasNextDouble())
            weight = sc.nextDouble();
          insert(new Edge(source, dest, weight));
        }
    }

    public static double breadthFirstSearch(MyGraph graph, int start)
    {

    }
    public static double depthFirstSearch(MyGraph graph, int start)
    {
        boolean [] arr1 = new boolean[graph.getNumV()];
        // this is visited array
        boolean [] arr2 = new boolean[graph.getNumV()];
    }
}

