import java.util.*;
import java.io.*;
/** 
  * Vertex class for representing the vertices in the graph.
  * A vertex must have an index (ID), a label, and a weight.
*/

public class Vertex
{
    // Data Fields
    private int indexID;
    private String label;
    private double weight;  
    //data structure which supports key/value pairing
    private HashMap<String, String> KVPairs = new HashMap<String, String>();

    // ---------- Constructors -------------------------------------------------------------------
    /** 
     * Construct a weighted vertex
    */
    public Vertex(int _id, String _label, double _weight)
    {
        this.indexID = _id;
        this.label = _label;
        this.weight = _weight;
        //setKVPairs("", "");
    }

    /** 
     * Construct an unweighted vertex
    */
    public Vertex(int _id, String _label)
    {
        this.indexID = _id;
        this.label = _label;
        // Default value of Vertex will be count as 1.0
        weight = 1.0;
        //setKVPairs("", "");
    }

    public Vertex(int _id)
    {
      this.indexID = _id;
      //setKVPairs("", "");
    }


    // ---------- Getters ------------------------------------------------------------------------
    /** Get the indexID
     */
    public int getIndexID() {return indexID;}

    /** Get the label of vertex
    */
    public String getLabel() {return label;}

    /** Get the weight of vertex
     */
    public double getWeight() {return weight;}

    public HashMap getKVPairs() {
      // System.out.println("KVPairs.size(): " + KVPairs.size());
      return KVPairs;}

    public String getKVPairs(String k) {
        //System.out.println("getted KVPairs.get(k): " + KVPairs.get(k));
      //System.out.println("KVPairs.size(): " + KVPairs.size());

      return KVPairs.get(k);}

    public void setKVPairs(String k, String v)
    {
        KVPairs.put(k, v);
    }


    // ---------- Methods -------------------------------------------------------------------------

    /** Return true if two vertex are equal. 
      * Vertexes are equal if the indexID, label and weight fields are equal. 
        @param obj The object to compare to
        @return true if the vertexes have the same indexID, label and weight  
     */
    public boolean equals(Object obj) 
    {
      if (obj instanceof Vertex) 
      {
        Vertex vertex = (Vertex) obj;
        return (indexID == vertex.indexID);
      }
      else 
        return false;
    }

    /** Return a String representation of the edge
        @return A String representation of the edge
     */
    public String toString() {
    StringBuffer sb = new StringBuffer("(");
    sb.append(Integer.toString(indexID));
    sb.append(")");
    return sb.toString();
  }

  public void printMap()
  {
        System.out.println(KVPairs);    
  }

  


  

    /** Return a hash code for an edge.  
      * The hash code is the source shifted left 16 bits exclusive or with the dest
        @return a hash code for an edge
     */
    public int hashCode() {
      return indexID;
    }


}
