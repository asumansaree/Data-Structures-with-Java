import java.util.*;

public class myGraphDriver
{
	public static void main(String[] args)
	{
        System.out.println("\n\nQUESTION-1\nMyGraph class' properties are TESTING...");
		MyGraph g = new MyGraph(5, false);
        g.insert(new Edge(0, 1, 1));
        g.insert(new Edge(0, 2, 2));
        g.insert(new Edge(1, 2, 3));
        g.insert(new Edge(1, 3, 4));
        g.printGraph();
        System.out.println("\nMethod: addVertex() is TESTING...");
        Vertex preVertex = g.addVertex(new Vertex(5));
        g.printGraph();
        System.out.println("\nMethod: addEdge() is TESTING...");
        g.addEdge(5, 4, 5);
        g.printGraph();
        System.out.println("\nMethod: removeEdge() is TESTING...");
        g.removeEdge(5, 4);
        g.printGraph();
        System.out.println("\nMethod: removeVertex(string label) is TESTING...");
        g.removeVertex(5);
        g.printGraph();
        System.out.println("\nMethod: exportMatrix() is TESTING...");
        g.exportMatrix();

        System.out.println("\n\nAdding user defined properties is TESTING...");
        System.out.println("\nAdd key: color, value: blue to the 5th vertex...");
        g.addUserDefProperty("color", "blue", preVertex);
        System.out.println("\nMethod: filterVertices is TESTING...");
        g.filterVertices("color", "blue");

        System.out.println("\nMethod: newVertex() is TESTING...");
        g.newVertex("test", 20.0);
        System.out.println("\n\nQUESTION-2\nBFS and DFS traversals are TESTING...");
        System.out.println("\n\nQUESTION-3\nModified Dijkstra is TESTING...");
        MyGraph g3 = new MyGraph(6, true);
        Vertex v0 = g3.addVertex(new Vertex(0));
        Vertex v1 = g3.addVertex(new Vertex(1));
        Vertex v2 = g3.addVertex(new Vertex(2));
        Vertex v3 = g3.addVertex(new Vertex(3));
        Vertex v4 = g3.addVertex(new Vertex(4));
        Vertex v5 = g3.addVertex(new Vertex(5));
        System.out.println("\n6 vertex (0, 1, 2, 3, 4, 5) are added.");

        g3.insert(new Edge(0, 1, 50.0));
        g3.insert(new Edge(0, 2, 45.0));
        g3.insert(new Edge(0, 3, 10.0));
        g3.insert(new Edge(1, 2, 10.0));
        g3.insert(new Edge(1, 3, 15.0));
        g3.insert(new Edge(2, 4, 30.0));
        g3.insert(new Edge(3, 0, 10.0));
        g3.insert(new Edge(3, 4, 15.0));
        g3.insert(new Edge(4, 1, 20.0));
        g3.insert(new Edge(4, 2, 35.0));
        g3.insert(new Edge(5, 4, 3.0));

        System.out.println("\nCreated Graph is: ");
        g3.printGraph();

        g3.addUserDefProperty("boostingValue", "0", v0);
        g3.addUserDefProperty("boostingValue", "7", v1);
        g3.addUserDefProperty("boostingValue", "5", v2);
        g3.addUserDefProperty("boostingValue", "9", v3);
        g3.addUserDefProperty("boostingValue", "1", v4);
        g3.addUserDefProperty("boostingValue", "0", v5);
        System.out.println("\nBoosting values are added (0, 7, 5, 9, 1, 0)");
        //g3.modifiedDijkstra(g3, v0);
        System.out.println("\n\nEND OF THE PROGRAM");
	}

}