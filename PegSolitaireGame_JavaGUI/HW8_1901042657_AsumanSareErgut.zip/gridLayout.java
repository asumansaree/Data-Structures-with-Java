	import javax.swing.*;
	import java.awt.*;
	import javax.swing.border.LineBorder;
	import java.awt.event.ActionListener;
	import java.awt.event.ActionEvent;
	import java.awt.GridLayout;
	import java.awt.FlowLayout; // specifies how components are arranged
	import javax.swing.JFrame; // provides basic window features
	import javax.swing.JLabel; // displays text and images
	import javax.swing.SwingConstants; // common constants used with Swing
	import javax.swing.Icon; // interface used to manipulate images
	import javax.swing.ImageIcon; // loads images
	import java.util.Scanner;
	import javax.swing.JScrollPane;
	import javax.swing.event.ListSelectionListener;
	import javax.swing.event.ListSelectionEvent;
	import javax.swing.ListSelectionModel;
	import javax.swing.JList;
	import java.awt.event.MouseListener;
	import java.awt.event.MouseMotionListener;
	import java.awt.event.MouseEvent;

	public class gridLayout extends JFrame implements ActionListener
	{
		private int size=13;
		private JButton[][] cells = new JButton[size][size];
		private int clicked = 0;
		private JLabel iconLabel1; // JLabel constructed with text and icon
		public static enum cell_stat{E, P, S, W} //E: Empty, P: Peg, S: Space, W: Wall
		private JList<String> directions;
		private final String dir[] = {"Left", "Right", "Up", "Down"};

		public gridLayout(String title) // Create JFrame
		{
			super(title);
			this.setSize(1000, 1000);
			this.setLocation(100, 100);
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	// column format
			JButton button1 = new JButton("Button1");
			JButton button2 = new JButton("Button2");
			JButton button3 = new JButton("Button3");
			JButton button4 = new JButton("Button4");
	// row format
			JButton button5 = new JButton("Reset Game");
			JButton button6 = new JButton("Load Game");
			JButton button7 = new JButton("Save Game");

	// columnt format
			JButton button9 = new JButton("Button9");
			JButton button10 = new JButton("Button10");
			JButton button11 = new JButton("Button11");

			Container mainContainer = this.getContentPane();
			mainContainer.setLayout(new BorderLayout(8, 6)); // Space between boxes
			mainContainer.setBackground(Color.YELLOW);
			this.getRootPane().setBorder(BorderFactory.createMatteBorder(4, 4, 4, 4, Color.GREEN));
	// Panel top
			JPanel topPanel = new JPanel();
	        topPanel.setBorder(new LineBorder(Color.BLACK, 3, true));
			topPanel.setBackground(Color.ORANGE);
			topPanel.setLayout(new FlowLayout(4)); // 4 button + 1 space

			topPanel.add(button1);
			topPanel.add(button2);
			topPanel.add(button3);
			topPanel.add(button4);
			mainContainer.add(topPanel, BorderLayout.NORTH);

	// Panel middle
			JPanel middlePanel = new JPanel();
			middlePanel.setBorder(new LineBorder(Color.BLACK, 3, true));
			middlePanel.setLayout(new FlowLayout(4, 4, 4));
			middlePanel.setBackground(Color.CYAN);

			JPanel gridPanel = new JPanel();
			gridPanel.setLayout(new GridLayout(4, 1, 5, 5));
			gridPanel.setBorder(new LineBorder(Color.BLACK, 3));
			gridPanel.setBackground(Color.RED);

			gridPanel.add(button5);
			gridPanel.add(button6);
			gridPanel.add(button7);

			middlePanel.add(gridPanel);
			mainContainer.add(middlePanel, BorderLayout.WEST);

	// Panel bottom
			JPanel bottomPanel = new JPanel();
			bottomPanel.setLayout(new FlowLayout(3));

			bottomPanel.add(button9);
			bottomPanel.add(button10);
			bottomPanel.add(button11);
			bottomPanel.setBackground(Color.MAGENTA);
			bottomPanel.setBorder(new LineBorder(Color.BLUE, 3));
			mainContainer.add(bottomPanel, BorderLayout.SOUTH);	
	 		mainContainer.add(setCells(9));

		} // end of the gridLayout constructor

		/*
		public void askForBoardType()
	    {
			setLayout( new FlowLayout() ); // set frame layout
	    	//final icon = new ImageIcon("home/Desktop/gui/board1.jpg"));
	    	Icon b1 = new ImageIcon("home/Desktop/gui/board1.jpg");
	    	iconLabel1 = new JLabel( "Type 1", b1, SwingConstants.LEFT );
	    	iconLabel1.setToolTipText( "BoardType1" );
	    	add(iconLabel1);
	    } 
		*/ 
		public void dirList() // 96
		{
			directions = new JList<String>();
			directions.setVisibleRowCount(4); // display 4 rows at once
			// do not allow multiple selections
			directions.setSelectionMode( ListSelectionModel.SINGLE_SELECTION );
			directions.addListSelectionListener(
				new ListSelectionListener() // anonymous inner class
				{
					// handle list selection events
					public void valueChanged( ListSelectionEvent event )
					{
						int index = (directions.getSelectedIndex());
						setCurrentDir(index);
					} // end method valueChanged
				} // end anonymous inner class
			); // end call to addListSelectionListener

		}

		public void setCurrentDir(int index)
		{
			switch(index)
			{
			case 0: System.out.println("Left");
				break;
			case 1: System.out.println("Right");
				break;
			case 2: System.out.println("Up");
				break;
			case 3: System.out.println("Down");
				break;
			}
		}

		public void actionPerformed(ActionEvent e) {
	         clicked++;}


		public JPanel setCells(int size) 
		{
			JPanel board = new JPanel();
			board.setLayout(new GridLayout(size, size, 1, 1));
			board.setBorder(new LineBorder(Color.BLACK, 3));
			board.setBackground(Color.RED);
//			board.setBorder(new LineBorder(Color.BLACK, 3));
	      // use layout managers to help you create your GUI
	      //setLayout(new GridLayout(size, size, 1, 1));
	      //ActionListener btnListener = new ButtonListener();
	      // create your buttons and add them only **once**

		// take user popup input here
		int boardChoice = 1;
		switch(boardChoice)
		{
		case 1: setBoard1(board, 11, 11);
			break;
		}
		return board;
	   } // end of the setCells method

		//public void makeMove()
		//public bool isValidMove()

	    public void setBoard1(JPanel board, int row, int col)
	    {
	    	int beginner_loc_x;
   	        int beginner_loc_y = 200;

	        for (int r = 0; r < row; r++) 
	        {
	      		beginner_loc_x = 450;
	            for (int c = 0; c < col; c++) 
	            {
		            JButton buttonW = new JButton(""); // button Wall
		            buttonW.addActionListener(this);
		            buttonW.setBackground(new Color(0,0,255));
		            buttonW.setVisible(false);
					buttonW.setBounds(beginner_loc_x,beginner_loc_y,50,50);

					JButton buttonP = new JButton("");
			        buttonP.addActionListener(this);
		            buttonP.setBackground(new Color(255,255,0));
		            buttonP.setVisible(true);
					buttonP.setBounds(beginner_loc_x,beginner_loc_y,50,50);

					JButton buttonE = new JButton("");
			        buttonE.addActionListener(this);
		            buttonE.setBackground(new Color(255,255,255));
		            buttonE.setVisible(true);
					buttonE.setBounds(beginner_loc_x,beginner_loc_y,50,50);

					beginner_loc_x += 50;
		            //add(buttonW);  // add button to a gridlayout using component
		            if(r == 4 && c == 5)
						cells[r][c] = buttonE; // assign Empty
					else if((r == 2 || r == 8) && (c == 4 || c==5 || c==6))
						cells[r][c] = buttonP; // assign Peg
					else if((r == 3 || r == 7) && (c==3 ||c == 4 || c==5 || c==6|| c==7))
						cells[r][c] = buttonP; // assign Peg
					else if((r == 4 || r == 5|| r == 6) && (c==2 ||c==3 ||c == 4 || c==5 || c==6|| c==7|| c==8))
						cells[r][c] = buttonP; // assign Peg
					else
						cells[r][c] = buttonW; // assign Wall
					cells[r][c].addMouseListener(new java.awt.event.MouseAdapter()
				    {
				        public void mousePressed(java.awt.event.MouseEvent evt)
				        {
				            JButton clickedButton = (JButton)evt.getSource();
				            //double y = evt.getY();
				            //newCube.setCube(x,y);
				            performOperation(board, clickedButton ,clickedButton.getX(), clickedButton.getY());
				            //System.out.println("You clicked the button" + x.getX() );
				            //System.out.println("\n\n*******\n\n");
				            //System.out.println(MouseInfo.getPointerInfo().getLocation() + " | ");
				        }
				    });
	            	add(cells[r][c]);
	         	}
	 			beginner_loc_y += 50;
	        }
	    }

	    public boolean performOperation(JPanel board, JButton B, int x, int y)
	    {
	    	//add(dirList());
	    	// Create popup menu, attach popup menu listener
		    JPopupMenu popupMenu = new JPopupMenu("Directions");
		    ActionListener actionListener = new PopupActionListener();

		    JMenuItem leftMenuItem = new JMenuItem("left");
		    popupMenu.add(leftMenuItem);
		    leftMenuItem.addActionListener(actionListener);

		    JMenuItem rightMenuItem = new JMenuItem("right");
		    popupMenu.add(rightMenuItem);
		    rightMenuItem.addActionListener(actionListener);


		    JMenuItem upMenuItem = new JMenuItem("up");
		    popupMenu.add(upMenuItem);
		    upMenuItem.addActionListener(actionListener);


		    JMenuItem downMenuItem = new JMenuItem("down");
		    popupMenu.add(downMenuItem);
		    downMenuItem.addActionListener(actionListener);

		    // Separator
		    popupMenu.addSeparator();

		    B.setComponentPopupMenu(popupMenu);

		    popupMenu.show(B, 0, 0);
		    return true;
	    }

		public static void main(String args[] )
		{
			/*
			LabelFrame labelFrame = new LabelFrame(); // create LabelFrame
			labelFrame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		    labelFrame.setSize( 275, 180 ); // set frame size
			labelFrame.setVisible( true ); // display frame
			
			*/
			gridLayout layout = new gridLayout("Peg Solitaire");
			layout.setVisible(true);
		} // end main

		
	} // end of the gridLayout class

class PopupActionListener implements ActionListener 
{
  public void actionPerformed(ActionEvent actionEvent) 
  {
  		String choosenDir = actionEvent.getActionCommand();
	    System.out.println("Selected: " + choosenDir);
	    switch(choosenDir)
	    {
	    case "left": //isValidMoveLeft();
	    	break;
	    case "right": //isValidMoveRight();
	    	break;
	    case "up": //isValidMoveUp();
	    	break;
	    case "down": //isValidMoveDown();
	    	break;
	    }
  }
}