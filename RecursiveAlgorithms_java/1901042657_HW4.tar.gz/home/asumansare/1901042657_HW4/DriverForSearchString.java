import pack.searchString;
import java.util.*;


public class DriverForSearchString
{  
    
    /** 
     * @param args
     */
    public static void main(String[] args) 
    {
        String Str = "ababjdabkfab";
        String subS = "ab";
        int occ = 4;
        System.out.println("Main string is: ababjdabkfab\nSubstring is: ab\nOccurence is: 4" );
        int retVal = searchString.searchStr(Str, subS, occ);
        if(retVal == -1)
            System.out.println("query string doesn’t occur in the big string or the number of occurences is less than i.");
        else 
            System.out.println("index of the " + occ + " th occurrence is: " + retVal);

        subS = "babj";
        occ = 1;
        System.out.println("\n\nMain string is: ababjdabkfab\nSubstring is: ab\nOccurence is: 4" );
        retVal = searchString.searchStr(Str, subS, occ);
        if(retVal == -1)
            System.out.println("query string doesn’t occur in the big string or the number of occurences is less than i.");
        else 
            System.out.println("index of the " + occ + " th occurrence is: " + retVal);

        subS = "babjsfas";
        occ = 1;
        System.out.println("\n\nMain string is: ababjdabkfab\nSubstring is: ab\nOccurence is: 4" );
        retVal = searchString.searchStr(Str, subS, occ);
        if(retVal == -1)
            System.out.println("query string doesn’t occur in the big string or the number of occurences is less than i.");
        else 
            System.out.println("index of the " + occ + " th occurrence is: " + retVal);
    }     
}

