import pack.sortedArray;
import java.util.*;

public class DriverForSortedArray
{  
    
    /** 
     * @param args
     */
    public static void main(String[] args) 
    {
    	int[] sortedArray0 = null;
        int[] sortedArray1 = new int[]{2, 8, 10, 20, 50, 60, 90};

        System.out.println("\n\nTESTING...IF ARRAY IS NULL");
        //System.out.println("Array: " + Arrays.toString(sortedArray1));         
        System.out.println("Lower Bound: 1\nUpper Bound: 20\n"); 
        System.out.println("numOfItems in sortedArray0 is: " + sortedArray.numOfItems(1, 50, sortedArray0, sortedArray0)); 
        System.out.println("In case array is null, item amount will be presented with -1\n"); 


        System.out.println("\n\nTESTING...WITH NORMAL ARRAY, WITH PROPER BOUNDS");
        System.out.println("Array1: " + Arrays.toString(sortedArray1));         
        System.out.println("Lower Bound: 8\nUpper Bound: 90"); 
        System.out.println("numOfItems in sortedArray1 is: " + sortedArray.numOfItems(8, 90, sortedArray1, sortedArray1)); 

        System.out.println("\n\nTESTING...WITH NORMAL ARRAY, BOUNDS' ORDER IS REVERSE (LOWER BOUND IS BIGGER THAN UPPER BOUND)");
        System.out.println("Array: " + Arrays.toString(sortedArray1));         
        System.out.println("Lower Bound: 90\nUpper Bound: 8\n"); 
        System.out.println("numOfItems in sortedArray1 is: " + sortedArray.numOfItems(90, 8, sortedArray1, sortedArray1)); 
        System.out.println("Program handles if bounds are given in reverse order by replacing them\n"); 

        int[] unsortedArray2 = new int[]{7, 10, 3, 9, 5};
        System.out.println("\n\nTESTING...WITH UNSORTED ARRAY, WITH PROPER BOUNDS");
        System.out.println("Array: " + Arrays.toString(unsortedArray2));         
        System.out.println("Lower Bound: 3\nUpper Bound: 9\n"); 
        int[] sortedArray2 = new int[unsortedArray2.length];
        //sortedArray2 = sortedArray.orderArr(unsortedArray2, sortedArray2, 0, 0, unsortedArray2[0]);
        //System.out.println("Sorted version of Array: " + Arrays.toString(sortedArray2));         
        //System.out.println("numOfItems in sortedArray1 is: " + sortedArray.numOfItems(8, 90, sortedArray1, sortedArray1)); 

        System.out.println("\n\nTESTING...WITH NORMAL ARRAY, IN CASE BOUNDS ARE NEIGHBOUR");
        System.out.println("Array: " + Arrays.toString(sortedArray1));         
        System.out.println("Lower Bound: 10\nUpper Bound: 20\n"); 
        System.out.println("numOfItems in sortedArray1 is: " + sortedArray.numOfItems(10, 20, sortedArray1, sortedArray1)); 

        System.out.println("\n\nTESTING...WITH NORMAL ARRAY, IN CASE BOUNDS ARE SAME");
        System.out.println("Array: " + Arrays.toString(sortedArray1));         
        System.out.println("Lower Bound: 10\nUpper Bound: 10\n"); 
        System.out.println("numOfItems in sortedArray1 is: " + sortedArray.numOfItems(10, 10, sortedArray1, sortedArray1)); 

        System.out.println("\n\nTESTING...WITH NORMAL ARRAY, BOUND IS THE MIDDLE ELEMENT DIRECTLY");
        System.out.println("Array: " + Arrays.toString(sortedArray1));         
        System.out.println("Lower Bound: 20\nUpper Bound: 50\n"); 
        System.out.println("numOfItems in sortedArray1 is: " + sortedArray.numOfItems(20, 50, sortedArray1, sortedArray1)); 

		System.out.println("\n\nTESTING...BOUND IS NOT IN THE ARRAY");
		System.out.println("Array: " + Arrays.toString(sortedArray1));         
        System.out.println("Lower Bound: 21\nUpper Bound: 57\n"); 
        System.out.println("Bound is not an element of the array\n"); 
        //System.out.println("numOfItems in sortedArray1 is: " + sortedArray.numOfItems(21, 50, sortedArray1, sortedArray1)); 

    }     
}

