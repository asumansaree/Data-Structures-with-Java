import pack.unsortedArray;
import java.util.*;

public class DriverForUnsortedArray
{  
    
    /** 
     * @param args
     */
    public static void main(String[] args) 
    {
        System.out.println("TESTING...CONTIGUOUS SUBARRAYS WHEN GIVEN SUM (1) IS NOT IN THE ARRAY\nEmpty means none.");
        int[] unsortedArray0 = new int[]{8, 2, 50, 4, 40, 44, 9};
        System.out.println("Array is: " + Arrays.toString(unsortedArray0));
        int[][] contSubarrays0 = new int[100][100]; 
        unsortedArray.findContiguous(contSubarrays0, unsortedArray0, 1, 0, unsortedArray0.length, 0);

        System.out.println("\n\nTESTING...CONTIGUOUS SUBARRAYS WHEN GIVEN SUM (50) IS IN THE ARRAY ONCE");
        int[] unsortedArray1 = new int[]{8, 2, 50, 4, 40, 44, 9};
        System.out.println("Array is: " + Arrays.toString(unsortedArray1));
        int[][] contSubarrays1 = new int[100][100]; 
        unsortedArray.findContiguous(contSubarrays1, unsortedArray1, 50, 0, unsortedArray1.length, 0);

        System.out.println("\n\nTESTING...CONTIGUOUS SUBARRAYS WHEN GIVEN SUM (44)IS IN THE ARRAY TWICE");
        int[] unsortedArray2 = new int[]{8, 2, 50, 4, 40, 44, 9};
        System.out.println("Array is: " + Arrays.toString(unsortedArray2));
        int[][] contSubarrays2 = new int[100][100]; 
        unsortedArray.findContiguous(contSubarrays2, unsortedArray2, 44, 0, unsortedArray2.length, 0);

        System.out.println("\n\nTESTING...CONTIGUOUS SUBARRAYS WHEN GIVEN SUM (8) WHEN ARRAY'S ELEMENTS ARE ALL SAME");
        int[] unsortedArray3 = new int[]{8, 8, 8, 8, 8};
        System.out.println("Array is: " + Arrays.toString(unsortedArray3));
        int[][] contSubarrays3 = new int[100][100]; 
        unsortedArray.findContiguous(contSubarrays3, unsortedArray3, 8, 0, unsortedArray3.length, 0);

        System.out.println("\n\nTESTING...WHEN ARRAY IS EMPTY");
        int[] unsortedArray4 = new int[]{};
        System.out.println("Array is: " + Arrays.toString(unsortedArray4));
        int[][] contSubarrays4 = new int[100][100]; 
        unsortedArray.findContiguous(contSubarrays4, unsortedArray4, 1, 0, unsortedArray4.length, 0);

        System.out.println("\n\nTESTING...WHEN ARRAY IS ALL CONSIST OF ZEROS");
        int[] unsortedArray5 = new int[]{};
        System.out.println("Array is: " + Arrays.toString(unsortedArray5));
        int[][] contSubarrays5 = new int[100][100]; 
        unsortedArray.findContiguous(contSubarrays5, unsortedArray5, 1, 0, unsortedArray5.length, 0);
    }     
}


