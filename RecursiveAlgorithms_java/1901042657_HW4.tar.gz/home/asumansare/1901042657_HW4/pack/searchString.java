package pack;
import java.util.*;

public class searchString
{   
    
    /** 
     * @param text
     * @param subString
     * @param occurAmount
     * @return int
     * Recursive function to search a given string in another given bigger string.  
     */
   public static int searchStr(String text, String subString, int occurAmount) 
    {
        if (text == null || text.equals("") || subString.equals("") || occurAmount == 0)
            return -1;
        else 
            return searchStr(text, subString, occurAmount, 0);
    }

    
    /** 
     * @param text
     * @param subString
     * @param occurAmount
     * @param i
     * @return int
     */
    public static int searchStr(String text, String subString, int occurAmount, int i) 
    {
        if(i == text.length() || i+subString.length() > text.length())
        {
            if(occurAmount == 0)
                return makeReverse(text, subString);
            else 
                return -1;  // The number of occurences is less than occ
        }
        else 
        {
            if(text.substring(i, i+subString.length()).equals(subString) == true)
            {
                --occurAmount;
            }
            return searchStr(text, subString, occurAmount, i+1);
        }
    }

    
    /** 
     * @param str
     * @param subStr
     * @return int
     */
    public static int makeReverse(String str, String subStr)
    {
        StringBuilder reverseStr = new StringBuilder();
        StringBuilder reverseSubStr = new StringBuilder();

        reverseStr.append(str);
        reverseSubStr.append(subStr);

        reverseStr.reverse();
        reverseSubStr.reverse();

        return lastIndex(reverseStr.toString(), reverseSubStr.toString(), 0);
    }

    
    /** 
     * @param str
     * @param subStr
     * @param i
     * @return int
     */
    public static int lastIndex(String str, String subStr, int i)
    {
        if(str.substring(i, i+subStr.length()).equals(subStr) == true)
            return str.length() - i - subStr.length();
        else 
            return lastIndex(str, subStr, i+1);
    }

}



