package pack;
import java.util.*;

/*
Suppose that you are given a sorted integer array. 
Suggest a recursive algorithm to find the number of items in the array between two given integer values. 
Hint: Consider an approach like binary search algorithm; compare given two integers with the middle element.
*/

public class sortedArray
{  
    
    /** 
     * @param lowerBound
     * @param upperBound
     * @param arr
     * @param arrUpdated
     * @return int
     */
    public static int numOfItems(int lowerBound, int upperBound, int[] arr, int[] arrUpdated)
    {
        if(lowerBound > upperBound || upperBound < lowerBound)
        {
            int temp = lowerBound;
            lowerBound = upperBound;
            upperBound = temp;
        }

        int[] startEndIndexes = new int[2];
        if(arr == null || arrUpdated == null)
            return -1;
        else if(lowerBound == (arrUpdated[arrUpdated.length/2]) || upperBound == (arrUpdated[arrUpdated.length/2]))
        {   
            //System.out.println("bound is equal to element in the middle (0)");
            int ind1 = findIndex(lowerBound, arr, 0);
            if(ind1 != -1)
                startEndIndexes[0] = ind1;
            int ind2 = findIndex(upperBound, arr, 0);
            if(ind2 != -1)
                startEndIndexes[1] = ind2;
            //System.out.println("indoflower:" + startEndIndexes[0]);
            //System.out.println("indofupper" + startEndIndexes[1]);
            int []finalArray = Arrays.copyOfRange(arr, startEndIndexes[0], (startEndIndexes[1]+1));
            // System.out.println("finalArray: " + Arrays.toString(finalArray));
            return finalArray.length;
        }
        else if(lowerBound < arrUpdated[arrUpdated.length/2])
        {
            //System.out.println("bound is less than element in the middle (1)");
            startEndIndexes[0] = 0;
            int ind2 = findIndex(arrUpdated[arrUpdated.length/2], arr, 0);
            if(ind2 != -1)
                startEndIndexes[1] = ind2;
            //System.out.println("end index: " + startEndIndexes[1]);
            int []firstRight = Arrays.copyOfRange(arr, startEndIndexes[0], (startEndIndexes[1]+1));
            //System.out.println("firstRight: " + Arrays.toString(firstRight));
            if(ind2 != -1)
                return numOfItems(lowerBound, upperBound, arr, firstRight);
            else return -1;
        }
        else 
        {
            //System.out.println("bound is bigger than element in the middle (2)");
            int ind1 = findIndex(arrUpdated[arrUpdated.length/2], arr, 0);
            if(ind1 != -1)
                startEndIndexes[0] = ind1;
            //System.out.println("start index: " + startEndIndexes[0]);
            startEndIndexes[1] = arr.length;
            int []lastLeft = Arrays.copyOfRange(arr, startEndIndexes[0], startEndIndexes[1]);
            //System.out.println("lastLeft: " + Arrays.toString(lastLeft));
            if(ind1 != -1)
                return numOfItems(lowerBound, upperBound, arr, lastLeft);
            else return -1;
        }

    }   

    
    /** 
     * @param target
     * @param array
     * @param i
     * @return int
     */
    public static int findIndex(int target, int[] array, int i)
    {
        if(target == array[i])
            return i;
        else 
        {
            if(i <= array.length)
                return findIndex(target, array, i+1);
            else
            {
                System.out.println("ELEMENT IS NOT IN THE ARRAY");
                return -1;
            }

        }
    }

    
    /** 
     * @param controlArr
     * @param updatedArr
     * @param i
     * @param rmv
     * @param rmvMarked
     * @return int[]
     */
    public static int[] removeElementFromArr(int[] controlArr, int[] updatedArr, int i, int rmv, boolean rmvMarked)
    {
        if(i == controlArr.length)
            return updatedArr = Arrays.copyOfRange(updatedArr, 0, updatedArr.length-1);
        else 
        {
            if(rmv == controlArr[i])
            {
                return removeElementFromArr(controlArr, updatedArr, i+1, rmv, true);
            }
            else 
            {
                if(rmvMarked == true)
                {
                    updatedArr[i] = controlArr[i+1];
                    return removeElementFromArr(controlArr, updatedArr, i+1, rmv, true);
                }
                else 
                {
                    updatedArr[i] = controlArr[i];
                    return removeElementFromArr(controlArr, updatedArr, i+1, rmv, false);
                }
            }
        }
    }

    
    /** 
     * @param controlArr
     * @param sortedArr
     * @param i
     * @param j
     * @param min
     * @return int[]
     */
    public static int[] orderArr(int[] controlArr, int[] sortedArr, int i, int j, int min)
    {
        if(controlArr.length == i)
            return sortedArr;
        else if(controlArr.length == j)
        {
            sortedArr[i] = min;
            int n = controlArr.length;
            int[] updatedArr = new int[n];            
            int[] tempArr = new int[n];
            int[] returnedArr = new int[n-1];

                    System.out.println("before update" + Arrays.toString(controlArr));         
            returnedArr = removeElementFromArr(controlArr, tempArr, 0, min, false);
                    System.out.println("after update" + Arrays.toString(returnedArr));         

            return orderArr(returnedArr, sortedArr, i+1, 0, controlArr[j]);
        }
        else 
        {
            if(controlArr[j] <= min)
            {
                min = controlArr[j];
                System.out.println("min: " + min + " i: " + i + " j: " + j);
            }
            System.out.println("min: " + min + " i: " + i + " j: " + j);
            return orderArr(controlArr, sortedArr, i, j+1, min);              
        }
    }

}
