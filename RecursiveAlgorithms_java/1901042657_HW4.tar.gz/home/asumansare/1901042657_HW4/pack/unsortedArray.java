package pack;
import java.util.*;

/*
    Suppose that you are given an unsorted integer array. 
    Propose a recursive solution to find contiguous subarray/s that the sum of its/theirs items is equal to a given integer value.
    Hint: Consider the following approach; the first element can be a part of the contiguous subarray or not. 
    You could perform two recursive calls based on these two cases.
*/

public class unsortedArray
{  
    
    /** 
     * @param contSubarrays
     * @param arr
     * @param targetSum
     * @param outerIndex
     * @param arrLen
     * @param countContSubArr
     * @return int[][]
     */
    public static int[][] findContiguous(int[][] contSubarrays, int[] arr, int targetSum, int outerIndex, int arrLen, int countContSubArr)
    {
        if(arrLen == 0)     
            return contSubarrays;
        else if(outerIndex == arrLen)
        {
            --arrLen;
            arr = Arrays.copyOfRange(arr, 0, arrLen);
            outerIndex = 0;
            return findContiguous(contSubarrays, arr, targetSum, outerIndex, arrLen, countContSubArr);
        }
        else
        {
            int [] controlArray = Arrays.copyOfRange(arr, outerIndex, arrLen);
            int sum = arraySum(controlArray, 0, 0);
            //System.out.println("Sum of elements of array " + Arrays.toString(controlArray) + " is " + sum);
            if(sum == targetSum)
            {
                contSubarrays[countContSubArr] = Arrays.copyOfRange(controlArray, 0, controlArray.length);
                System.out.println("Sum of elements of array " + Arrays.toString(contSubarrays[countContSubArr]) + " is " + sum);
                return findContiguous(contSubarrays ,arr, targetSum, outerIndex+1, arrLen, countContSubArr+1);
            }
            else 
                return findContiguous(contSubarrays ,arr, targetSum, outerIndex+1, arrLen, countContSubArr);
        }
    }

    
    /** 
     * @param arr
     * @param sum
     * @param i
     * @return int
     */
    public static int arraySum(int[] arr, int sum, int i)
    {
        if(arr.length == i)
            return sum;
        else
        {
            sum += arr[i];
            return arraySum(arr, sum, i+1);
        }
    }
}
