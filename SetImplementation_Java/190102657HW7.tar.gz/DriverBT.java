import tree.BinaryTree;
import tree.SearchTree;
import tree.BinarySearchTree;

import java.util.*;

public class DriverBT
{
    public static void main(String[] args)
    {
        BinaryTree<Integer> node1 = new BinaryTree<Integer>(40, null, null);
        BinaryTree<Integer> node2 = new BinaryTree<Integer>(25, node1, null);
        BinaryTree<Integer> node3 = new BinaryTree<Integer>(10, node2, new BinaryTree<Integer>(30, null, null));
        BinaryTree<Integer> root1 = new BinaryTree<Integer>(7, node3, new BinaryTree<Integer>(3, null, null));

        System.out.print("\n\nBinary Tree:\n");
        root1.inOrderPrinting();

        Integer[] arr = new Integer[6];
        arr[0] = 14;
        arr[1] = 1;
        arr[2] = 49;
        arr[3] = 35;
        arr[4] = 6;
        arr[5] = 4;

        System.out.println("\n\nArray: \n");
        for (Integer i : arr) {
            System.out.print(i + " ");
        }

        BinarySearchTree<Integer> root2 = BinarySearchTree.btToBstFromArray(root1, arr);
        System.out.println("\n\n\nBinary Search Tree:\n\n");
        root2.inOrderPrinting();

    }
}